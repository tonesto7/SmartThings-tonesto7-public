'use strict';

class HelpClass {
    constructor(esClass) {
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.attributes = esClass.alexaHandler.attributes;
        this.response = esClass.alexaHandler.response;
        this.alexaHandler = esClass.alexaHandler;
        this.emit = esClass.alexaHandler.emit;
        this.event = esClass.alexaHandler.event;
        this.esData = esClass.esData;
        this.hereData = esClass.hereData;
        this.allowPersonality = esClass.allowPersonality;
        this.followupMode = esClass.followupMode;
        this.respMap = esClass.respStrings;
        this.utils = esClass.utils;
        this.devId = esClass.alexaHandler.handler.theId;
        this.skillName = 'EchoSistant Help';
        this.echoHasDisplay = esClass.echoHasDisplay;
        this.helpItems = esClass.utils.helpItems();
        this.helpItemsDesc = esClass.utils.helpItemsDesc();
        // this.settingItems = esClass.utils.settingItems();
    }

    ignoreCmds() {
        return [
            'siren',
            'both',
            'strobe',
            'inactive',
            'active',
            'departed',
            'arrived',
            'changeOperState',
            'changePresence',
            'emergencyHeat',
            'runSmokeTest',
            'runCoTest',
            'runBatteryTest',
            'playSoundAndTrack',
            'playRepeatTrackAtVolume',
            'playRepeatTrack',
            'playTrackAtVolume',
            'chgStreaming',
            'flip',
            'ecobtn',
            'inactive',
            'changeMode',
            'setPresence',
            'updateNestReportData',
            'setArmedNight',
            'setArmedStay',
            'setDisarmed',
            'acknowledgeArmRequest',
            'setArmedAway',
            'test',
            'startActivity',
            'activityoff',
            'setZoneWaterTime',
            'superDuper',
            'updateDeviceStatus',
            'updateDeviceLastActivity',
            'updateDeviceMoving',
            'whiteLights',
            'tvTime',
            'blueLights',
            'take'
        ];
    }

    ignoreCaps() {
        return ['Power Meter'];
    }

    actNeedsValue() {
        return ['setpoint', 'dark', 'bright', 'cooler', 'warmer'];
    }

    getActions() {
        var res = [];
        let splitCmd;
        let tmp = [...new Set(this.esData.devData.map(r => r.commands).reduce((a, b) => a.concat(b)))].map(a => {
            splitCmd = a.replace(/:.*/, '').split(/(?=[A-Z]+[^A-Z]?)/);
            if (splitCmd.length > 1) {
                splitCmd = splitCmd.join(' ');
            }
            res.push(this.utils.cleanString(splitCmd.toString() || ''));
        });
        // console.log("allActions: " + res);
        return res;
    }

    randomAction() {
        var res = [];
        let splitCmd;
        let tmp = [...new Set(this.esData.devData.map(r => r.commands).reduce((a, b) => a.concat(b)))].map(a => {
            splitCmd = a.replace(/:.*/, '').split(/(?=[A-Z]+[^A-Z]?)/);
            if (splitCmd.length > 1) {
                splitCmd = splitCmd.join(' ');
            }
            res.push(this.utils.cleanString(splitCmd.toString() || ''));
        });
        // console.log("allActions: " + res);
        return this.utils.getRandomItem(res);
    }

    randomType() {
        var res = [];
        let tmp = [...new Set(this.esData.devData.map(r => r.capabilities).reduce((a, b) => a.concat(b)))].map(a => res.push(this.utils.cleanString(a || '')));
        // console.log("allDevTypes: " + res);
        return this.utils.getRandomItem(res);
    }

    randomRoom() {
        var res = [];
        let tmp = [...new Set(this.esData.devData.map(r => r.rooms).reduce((a, b) => a.concat(b)))].map(a => res.push(this.utils.cleanString(a)));
        // console.log("allRooms: " + res);
        return this.utils.getRandomItem(res);
    }

    // Random Item Generators
    randomCmdPrefix() {
        return this.utils.getRandomItem(['set ', 'turn ', 'change ', 'make ', 'all ']);
    }

    randomModePrefix() {
        return this.utils.getRandomItem(['set ', 'mode to ', 'change mode to ', 'set to ', 'change to ']);
    }

    randomRoutinePrefix() {
        return this.utils.getRandomItem(['run ', 'execute ', 'start ', '']);
    }

    randomRoomPrefix() {
        return this.utils.getRandomItem([' in the ', ' in ']);
    }

    createRangeArray(from = 0, too = 0, incr = 1) {
        let vals = [];
        for (var i = from; i <= too;) {
            vals.push(i);
            i = i + incr;
        }
        return vals;
    }

    getAllowedItem(items, ignItems) {
        let itemOk = false;
        let cycleCnt = 0;
        while (items.length >= 1 && itemOk === false && cycleCnt <= 10) {
            let item = this.utils.getRandomItem(items);
            if (item !== undefined) {
                if (!this.stringInArray(ignItems, item.toString(), 'getAllowedItem()')) {
                    itemOk = true;
                    return item;
                } else {
                    items.splice(items.indexOf(item), 1);
                }
            }
            cycleCnt++;
            // console.log("items: (" + items.length + ")");
        }
        return undefined;
    }

    stringInArray(arr, str, sender, fuzzy = false, showLog = false) {
        for (let item in arr) {
            if (showLog) {
                console.log('item: (' + arr[item] + ') | str: [' + str + ']', '(' + arr[item].includes(str) + ') | fuzzy: [' + fuzzy + '] | (' + sender + ')');
            }
            if (fuzzy === true) {
                if (arr[item].includes(str)) {
                    return true;
                }
            } else {
                if (arr[item] === str) {
                    return true;
                }
            }
        }
        return false;
    }

    getRandomExampleItems(items, cnt) {
        let res = [];
        while (res.length < cnt && items.length > 0) {
            let item = this.utils.getRandomItem(items);
            if (!(item === 'device' && res.filter(i => i === item).length < 2)) {
                items.splice(items.indexOf(item), 1);
            }
            res.push(item);
        }
        return res;
    }

    searchString(string, search) {
        const result = [];
        const regEx = new RegExp(search, 'gi');
        let match;
        while ((match = regEx.exec(string))) {
            result.push(
                Object({
                    theMatch: match[0],
                    index: match.index
                })
            );
        }
        return result;
    }

    /// //////////////////////////////////////////////////////////////
    //                  END HELPER FUNCTIONS
    /// //////////////////////////////////////////////////////////////

    handleHelp() {
        console.log('handleSettings| helpStage: ' + this.attributes.helpStage);
        const ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        const helpItems = this.helpItems;
        const helpItemsDesc = this.helpItemsDesc;

        if (ttstext !== undefined) {
            console.log('handleHelp | ttstext: ' + ttstext);
        }
        // this.attributes.helpStage = "needHelpType";
        if (this.attributes.helpStage === 'needHelpType') {
            console.log('helpStage: needHelpType');
            if (ttstext === undefined) {
                console.log('helpStage: needHelpType NO ttstext');
                // NOTE: This prompts for the help item to provide...
                this.attributes.speechOutput = this.utils.getSpeechItem(this.respMap.Help, 'Type', this.allowPersonality).toString();
                this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Type_Reprompts', this.allowPersonality).toString();
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));

                if (this.echoHasDisplay === true) {
                    this.response.renderTemplate(
                        this.utils.generateShowCard({
                            skillName: 'Available Help',
                            listItems: this.utils.showListItemsBuilder(helpItemsDesc.sort(), 'helpOptsItem'),
                            token: 'helpItemsList',
                            type: 'list1'
                        })
                    );
                }
                return this.emit(':responseReady');
            } else {
                console.log('helpStage: needHelpType ttstext available');
                let helpMatch = false;
                let helpType;
                let roomDevice = ttstext.match('\\b(device)(?:(?:es|s)?)\\b') || ttstext.includes('device');
                let roomShort = ttstext.match('\\b(short|cut|shortcut)(?:(?:es|s)?)\\b') || ttstext.includes('shortcut') || ttstext.includes('short cut');
                if (roomDevice || roomShort) {
                    helpMatch = true;
                    console.log('helpItem (roomDevice: ' + roomDevice + ' | roomShort: ' + roomShort + ') MATCHED:' + ttstext);
                    if (roomShort) {
                        this.attributes.helpStage = 'helpNeedShortcutRoom';
                        helpType = 'shortcut in room';
                    } else {
                        this.attributes.helpStage = 'helpNeedDeviceRoom';
                        helpType = 'device in room';
                    }
                    const allRoomNames = this.esData.locData.availableRooms.map(room => room.name);
                    this.attributes.speechOutput = this.utils.getSpeechItem(this.respMap.Help, 'Room', this.allowPersonality).toString();
                    this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Room_Reprompts', this.allowPersonality).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Room List',
                            listItems: this.utils.showListItemsBuilder(allRoomNames.sort(), 'hereRoomItem'),
                            token: 'hereRoomList',
                            type: 'list1'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                } else {
                    helpItems.forEach(item => {
                        if (ttstext.match('\\b(' + item + ')(?:(?:es|s)?)\\b') || ttstext.includes(item)) {
                            console.log('helpItem MATCHED:' + item);
                            helpType = item;
                            helpMatch = true;
                        }
                    });
                    if (helpMatch === true && helpType !== undefined) {
                        this.attributes.helpStage = 'helpTypeFound';
                        switch (helpType) {
                            case 'examples':
                            case 'example':
                                this.attributes.speechOutput = this.getHelpExamples();
                                break;
                            case 'routines':
                            case 'routine':
                                this.attributes.speechOutput = this.getRoutinesList();
                                break;
                            case 'modes':
                            case 'mode':
                                this.attributes.speechOutput = this.getModeList();
                                break;
                            case 'rooms':
                            case 'room':
                                this.attributes.speechOutput = this.getRoomList();
                                break;
                        }
                        this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.utils.getSpeechItem(this.respMap.Help, 'Reprompts', this.allowPersonality)));
                        if (this.echoHasDisplay === true) {
                            this.response.renderTemplate(
                                this.utils.generateShowCard({
                                    skillName: 'Help Response',
                                    priText: this.attributes.speechOutput,
                                    type: 'body6'
                                })
                            );
                        }
                        this.attributes.helpStage = undefined;
                        this.attributes.helpType = undefined;
                        this.attributes.helpModeType = undefined;
                        this.attributes.helpModeStage = undefined;
                        return this.emit(':responseReady');
                    } else {
                        console.log('!!!Help Type NOT Matched!!!');
                        this.attributes.speechOutput = this.utils.getSpeechItem(this.respMap.Help, 'Type_List', this.allowPersonality).toString() + helpItemsDesc.sort().join(', <break time="500ms"/>');
                        this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Type_Reprompts', this.allowPersonality).toString();
                        this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));

                        if (this.echoHasDisplay === true) {
                            this.response.renderTemplate(
                                this.utils.generateShowCard({
                                    skillName: 'Available Help',
                                    listItems: this.utils.showListItemsBuilder(helpItemsDesc.sort(), 'helpOptsItem'),
                                    token: 'helpItemsList',
                                    type: 'list1'
                                })
                            );
                        }
                        return this.emit(':responseReady');
                    }
                }
            }
        }
        if (this.attributes.helpStage === 'helpNeedDeviceRoom' || this.attributes.helpStage === 'helpNeedShortcutRoom') {
            console.log('helpStage: ' + this.attributes.helpStage);
            const allRoomNames = this.esData.locData.availableRooms.map(room => room.name);

            let roomMatch = false;
            let matchedRoom;
            if (ttstext !== undefined) {
                for (const room of allRoomNames.sort()) {
                    if (this.utils.cleanString(this.event.request.intent.slots.ttstext.value).match('\\b' + room.toLowerCase() + '\\b')) {
                        roomMatch = true;
                        matchedRoom = room.toLowerCase();
                    }
                }
                if (roomMatch && matchedRoom) {
                    if (this.attributes.helpStage === 'helpNeedDeviceRoom') {
                        this.attributes.speechOutput = this.getRoomDevicesList(matchedRoom);
                    } else if (this.attributes.helpStage === 'helpNeedShortcutRoom') {
                        this.attributes.speechOutput = this.getRoomDevicesList(matchedRoom, 'Shortcut');
                    }

                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.utils.getSpeechItem(this.respMap.Help, 'Reprompts', this.allowPersonality)));
                    if (this.echoHasDisplay === true) {
                        this.response.renderTemplate(
                            this.utils.generateShowCard({
                                skillName: 'Help Response',
                                priText: this.attributes.speechOutput,
                                type: 'body6'
                            })
                        );
                    }
                    this.attributes.helpStage = undefined;
                    this.attributes.helpType = undefined;
                    this.attributes.helpModeType = undefined;
                    this.attributes.helpModeStage = undefined;
                    return this.emit(':responseReady');
                } else {
                    console.log('!!!Room NOT Matched!!!');
                    this.attributes.speechOutput = this.utils.getSpeechItem(this.respMap.Help, 'Room_Missed', this.allowPersonality).toString();
                    this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Room_Missed_List', this.allowPersonality).toString() + allRoomNames.sort().join(', <break time="500ms"/>');
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        this.response.renderTemplate(
                            this.utils.generateShowCard({
                                skillName: 'Help - Room Name Not Understood',
                                listItems: this.utils.showListItemsBuilder(allRoomNames.sort(), 'roomItem'),
                                token: 'roomList',
                                type: 'list1'
                            })
                        );
                    }
                    return this.emit(':responseReady');
                }
            } else {
                console.log('!!!Room NOT Received!!!');
                this.attributes.speechOutput = this.utils.getSpeechItem(this.respMap.Help, 'Room_Reprompts', this.allowPersonality).toString();
                this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Room_Reprompts_List', this.allowPersonality).toString() + allRoomNames.sort().join(', <break time="500ms"/>');
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                if (this.echoHasDisplay === true) {
                    this.response.renderTemplate(
                        this.utils.generateShowCard({
                            skillName: 'Help - Room Name Not Received',
                            listItems: this.utils.showListItemsBuilder(allRoomNames.sort(), 'roomItem'),
                            token: 'roomList',
                            type: 'list1'
                        })
                    );
                }
                return this.emit(':responseReady');
            }
        }
    }

    getHelpExamples() {
        let resp = '';
        const exampleCnt = this.utils.getRandomItem([2, 3, 4]);
        const types = this.getRandomExampleItems(['shortcut', 'mode', 'device', 'routine'], exampleCnt);
        console.log('types: ' + types + ' | cnt: ' + exampleCnt);
        for (const t in types) {
            if (types[t]) {
                let addResp = '';
                addResp += this.getExampleByType(types[t], t >= types.length - 1);
                console.log(types[t] + '(' + t + '): (addResp: ' + addResp.length + ') | type: ' + types[t]);
                if (addResp.length > 0 && t < types.length - 1) {
                    addResp += this.utils.getRandomItem([' and ']);
                }
                resp += addResp;
            }
        }
        let preResp = this.utils.getRandomItem(['Some examples are:, ', 'Here are some examples, ']);
        return preResp + resp;
    }

    getExampleByType(objType, end = false) {
        let res;
        // let runCount = 0;
        let lineEnd = end ? '.' : ',';
        switch (objType) {
            case 'shortcut':
                res = this.randomShortcut() + ' in here' + lineEnd;
                break;
            case 'mode':
                res = this.randomModePrefix() + this.randomMode() + lineEnd;
                break;
            case 'routine':
                res = this.randomRoutinePrefix() + this.randomRoutine() + lineEnd;
                break;
            case 'device':
                while (res === undefined) {
                    res = this.getRandomDeviceResp() + lineEnd;
                    // runCount++;
                }
                // console.log("Device Response(CycleCount: " + runCount + "): " + res);
                break;
        }
        return res;
    }

    getModeList() {
        const modes = this.esData.locData.availStModes.map(m => this.utils.cleanString(m.name));
        if (modes.length) {
            return this.utils.getRandomItem(['The modes available are: ', 'Here are the available modes: ']) + modes.sort().join(', <break time="500ms"/>');
        } else {
            return "I wasn't able to find any modes to return";
        }
    }

    getRoutinesList() {
        const routines = this.esData.locData.availStRoutines.map(r => this.utils.cleanString(r.name));
        if (routines.length) {
            return this.utils.getRandomItem(['The routines available are: ', 'Here are the available routines: ']) + routines.sort().join(', <break time="500ms"/>');
        } else {
            return "I wasn't able to find any routines to return";
        }
    }

    getRoomList() {
        const rooms = [...new Set(this.esData.devData.map(r => r.rooms).reduce((a, b) => a.concat(b)))].map(a => this.utils.cleanString(a));
        if (rooms.length) {
            return this.utils.getRandomItem(['The rooms available are: ', 'Here are the available rooms: ', 'The available rooms are: ']) + rooms.sort().join(', <break time="500ms"/>');
        } else {
            return "I wasn't able to find any rooms to return";
        }
    }

    getRoomDevicesList(roomName, type = undefined) {
        roomName = this.utils.capitalize(roomName);
        let roomMatch;
        let desc = type ? this.utils.pluralize(type) : this.utils.pluralize('device');
        for (const room of this.esData.locData.availableRooms.map(room => room.name).sort()) {
            if (this.utils.cleanString(roomName).match('\\b' + room.toLowerCase() + '\\b')) {
                roomMatch = room;
            }
        }
        if (roomMatch !== undefined) {
            const devs = [];
            this.esData.devData.filter(theDevice => (type !== undefined ? theDevice.capabilities.includes(this.utils.capitalize(type)) && theDevice.rooms.includes(roomMatch) : theDevice.rooms.includes(roomMatch))).map(obj => devs.push(this.utils.cleanString(obj.label)));
            return devs.length ? this.utils.getRandomItem(['The ' + desc + ' available in the ' + roomMatch + ' are ', 'The ' + roomMatch + ' ' + desc + ' are ']) + devs.sort().join(', <break time="500ms"/>') : "Something went wrong!  I couldn't find any " + desc + ' for the room: ' + roomMatch;
        } else {
            return "I wasn't able to find a room named, " + roomName;
        }
    }

    randomShortcut() {
        const res = [];
        this.esData.devData.filter(theDevice => theDevice.capabilities.includes('Shortcut')).map(obj => res.push(this.utils.cleanString(obj.label)));
        return this.utils.getRandomItem(res);
    }

    randomMode() {
        const res = [];
        this.esData.locData.availStModes.map(obj => res.push(this.utils.cleanString(obj.name)));
        return this.utils.getRandomItem(res);
    }

    randomRoutine() {
        const res = [];
        this.esData.locData.availStRoutines.map(obj => res.push(this.utils.cleanString(obj.name)));
        return this.utils.getRandomItem(res);
    }

    getRandomDeviceResp() {
        const idRes = [];
        this.esData.devData.filter(theDevice => !theDevice.capabilities.includes('Shortcut') && !theDevice.label.startsWith('vCal') && !theDevice.label.startsWith('presence') && (theDevice.commands !== undefined ? theDevice.commands.length > 0 : false) && (theDevice.capabilities !== undefined ? theDevice.capabilities.length > 0 : false)).map(obj => idRes.push(obj.deviceId));
        const devId = this.utils.getRandomItem(idRes);
        let theDevice;
        this.esData.devData.filter(theDevice => theDevice.deviceId === devId).map(dev => (theDevice = { id: dev.deviceId, name: this.utils.cleanString(dev.label), capabilities: dev.capabilities, commands: dev.commands, rooms: dev.rooms }));

        // console.log("theDevice: ", theDevice);
        if (theDevice !== undefined) {
            const room = this.utils.getRandomItem([undefined, this.utils.getRandomItem(theDevice.rooms)]);
            let action = this.getAllowedItem(theDevice.commands, this.ignoreCmds());
            let value;
            if (action) {
                console.log('action: ' + this.utils.decamelize(action));
                const type = this.getAllowedItem(theDevice.capabilities, this.ignoreCaps());
                console.log('type: ' + type);
                let pType = type;
                switch (action) {
                    case 'on':
                    case 'off':
                        console.log('on || off');
                        if (room !== undefined) {
                            return this.utils.getRandomItem(['turn ' + action + this.utils.getRandomItem([' all', '']) + ' the ' + this.utils.pluralize(pType) + this.randomRoomPrefix() + room, 'turn ' + room + ' ' + this.utils.pluralize(pType) + ' ' + action]);
                        } else {
                            return this.utils.getRandomItem(['turn ' + action + ' the ' + theDevice.name, 'turn the ' + theDevice.name + ' ' + action]);
                        }
                    case 'open':
                    case 'close':
                    case 'lock':
                    case 'unlock':
                        console.log('open || close || lock || unlock');
                        if (room !== undefined) {
                            return this.utils.getRandomItem([action + ' the ' + this.utils.pluralize(pType) + this.randomRoomPrefix() + room]);
                        } else {
                            return this.utils.getRandomItem([action + ' the ' + theDevice.name]);
                        }

                    default:
                        const lowAction = action.toLowerCase();
                        const needsValue = this.stringInArray(this.actNeedsValue(), this.utils.decamelize(action), 'needsValue', true);

                        if (action.startsWith('set') || needsValue) {
                            console.log('default(set || needsValue)');
                            if (lowAction.includes('color')) {
                                value = this.utils.getRandomItem([...new Set(this.utils.getColorData().map(r => r.colorName))]);
                                console.log(value);
                            } else if (lowAction.includes('level') || needsValue) {
                                value = this.utils.getRandomItem(this.createRangeArray());
                            }

                            if (value) {
                                if (room !== undefined) {
                                    return this.utils.getRandomItem(['set the ' + this.utils.decamelize(action.substring(3)) + ' of the ' + this.utils.pluralize(pType) + this.randomRoomPrefix() + room + ' to ' + value, 'change the ' + room + ' ' + this.utils.pluralize(pType) + ' to ' + this.utils.decamelize(action) + ' ' + value]);
                                } else {
                                    return this.utils.getRandomItem(['set the ' + this.utils.decamelize(action.substring(3)) + 'on the ' + theDevice.name + ' to ' + value, 'change the ' + this.utils.decamelize(action.substring(3)) + 'on the ' + theDevice.name + ' to ' + value]);
                                }
                            }
                        } else if (action.startsWith('get')) {
                            return undefined;
                        } else if (this.stringInArray(['bright', 'dark', 'fast', 'slow', 'warm', 'cold'], action, 'else if', true, false)) {
                            console.log('bright || dark || fast || slow || warm || cold');
                            if (action.includes('warm') || action.includes('cold') || (action.includes('down') && pType.includes('temperature')) || (action.includes('down') && pType.includes('temperature'))) {
                                value = this.esData.locData.temp_scale === 'F' ? this.createRangeArray(50, 90, 1) : this.createRangeArray(9, 32, 0.5);
                            } else {
                                value = this.utils.getRandomItem(this.createRangeArray());
                            }
                            action = this.utils.pluralize(action);
                            if (room !== undefined) {
                                return this.utils.getRandomItem(['make the ' + this.utils.pluralize(pType) + ' ' + action + this.randomRoomPrefix() + room]);
                            } else {
                                return this.utils.getRandomItem(['make ' + theDevice.name + ' ' + action]);
                            }
                        } else {
                            console.log('default(else)');
                            return this.utils.getRandomItem([this.utils.decamelize(action) + this.utils.getRandomItem([' the ', ' on the ']) + theDevice.name]);
                        }
                }
            }
        }
        return undefined;
    }
}
module.exports = HelpClass;