'use strict';

const appVersion = '5.0.0110';
const appVerDate = '01/10/2018';
const esUtils = require('./es_mod_utils.js');
const esDebug = require('./es_mod_debug.js');
const esDatabase = require('./es_mod_db.js');
const esHere = require('./es_mod_here.js');
const esSettings = require('./es_mod_settings.js');
const esStatusInfo = require('./es_mod_statusinfo.js');
const esHelpClass = require('./es_mod_help.js');
const esParser = require('./es_mod_parser.js').Parser;
const esRespMap = require('./es_response_map.js');
const imgPathUrl = 'https://echosistant.com/es5_content/images/';
class EchoSistant {
    constructor(alexaHandler) {
        this.appVersion = appVersion;
        this.appVerDate = appVerDate;
        this.imgPathUrl = imgPathUrl;
        this.alexaHandler = alexaHandler;
        this.stHost = process.env.stHost.split(':')[0];
        this.stPort = process.env.stHost.split(':')[1];
        this.stPath = process.env.stPath;
        this.stAppID = process.env.stPath.split('/')[4];
        this.esData = alexaHandler.esData;
        this.hereData = alexaHandler.hereData;
        this.allowPersonality = this.esData.settings.allowPersonality !== false || true;
        this.followupMode = this.esData.settings.followupMode !== false || true;
        this.echoHasDisplay = !!alexaHandler.event.context.System.device.supportedInterfaces.Display;
        this.devName = '';
        this.respStrings = this.respMap();
        this.utils = this.utils();
        this.helpInfo = this.helpClass();
    }

    utils() {
        return new esUtils(this);
    }
    respMap() {
        return new esRespMap(this).staticResponses();
    }
    database() {
        return new esDatabase(this);
    }
    debug() {
        return new esDebug(this);
    }
    here() {
        return new esHere(this);
    }
    settings() {
        return new esSettings(this);
    }
    parser() {
        return new esParser(this);
    }
    statusInfo() {
        return new esStatusInfo(this);
    }
    helpClass() {
        return new esHelpClass(this);
    }
}

module.exports = EchoSistant;