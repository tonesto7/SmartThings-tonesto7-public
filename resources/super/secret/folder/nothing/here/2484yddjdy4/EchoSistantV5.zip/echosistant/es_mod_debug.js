'use strict';
const aws = require('aws-sdk');

class Debug {
    constructor(esClass) {
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.esData = esClass.esData;
        this.hereData = esClass.hereData;
        this.utils = esClass.utils;
        this.devName = esClass.devName;
        this.stAppID = esClass.stAppID;
    }
    sendDebugLogs() {
        const cloudwatchlogs = new aws.CloudWatchLogs({
            apiVersion: '2014-03-28'
        });
        const params = {
            logGroupName: '/aws/lambda/EchoSistantV5',
            filterPattern: 'ESLogging',
            interleaved: true
        };
        const self = this;
        if (self.esData.settings.sendDebugData === true) {
            cloudwatchlogs.filterLogEvents(params, function(err, data) {
                if (err) {
                    console.error('ESLogging|', err, err.stack);
                } else {
                    const payload = JSON.stringify({
                        cloudWatchLogs: data.events,
                        devName: self.devName,
                        lambVer: self.appVersion,
                        lambDt: self.appVerDate,
                        esData: self.esData,
                        hereData: self.hereData,
                        userData: self.userData,
                        tz: new Date().toString()
                    });
                    const headers = {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(payload, 'utf8')
                    };
                    const options = {
                        host: 'echosistant-analytics.firebaseio.com',
                        path: '/awsDebug/' + self.stAppID + '/info.json',
                        port: '443',
                        method: 'PUT',
                        headers: headers
                    };
                    self.utils
                        .httpRequest(options, payload)
                        .then(function(resp) {
                            console.log('ESLogging | Debug Data Send'); //, JSON.stringify(resp));
                        })
                        .catch(function(err) {
                            console.error('ESLogging | Debug Data Send', err);
                        });
                }
            });
        }
    }

    sendRequestLogs(requestType, data) {
        const self = this;
        if (self.esData.settings.sendDebugData === true) {
            const payload = JSON.stringify({
                origin: requestType,
                intent: (data.event.request !== undefined && data.event.request.intent !== undefined ? data.event.request.intent : undefined) || '',
                devName: self.devName,
                name: data.name,
                theId: data.theId,
                lambVer: self.appVersion,
                lambDt: self.appVerDate,
                ttstext: (data.event.request !== undefined && data.event.request.intent !== undefined && data.event.request.intent.slots !== undefined && data.event.request.intent.slots.ttstext !== undefined ? data.event.request.intent.slots.ttstext.value : undefined) || '',
                handler: data.handler,
                event: data.event,
                attributes: data.attributes,
                context: data.context,
                response: data.response,
                tz: new Date().toString()
            });
            // console.log('sendRequestLogs: ' + payload);
            const postHeaders = {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(payload, 'utf8')
            };
            const options = {
                host: 'echosistant-analytics.firebaseio.com',
                path: '/debug/' + self.stAppID + '/requestData/' + requestType + '.json',
                port: '443',
                method: 'POST',
                headers: postHeaders
            };
            self.utils
                .httpRequest(options, payload)
                .then(function(resp) {
                    console.log('ESLogging | Debug Request Log Send'); //, JSON.stringify(resp));
                })
                .catch(function(err) {
                    console.error('ESLogging | Debug Request Logs Error: ', err);
                });
        }
    }
}

module.exports = Debug;