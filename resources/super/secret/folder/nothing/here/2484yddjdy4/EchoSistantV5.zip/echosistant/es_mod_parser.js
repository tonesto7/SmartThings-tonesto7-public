'use strict';
/*
    TODO: Status: Allow users to tag a room with a group for easy status reports.   Example(tag room as 'upstairs' or 'downstairs')
    TODO: Status: Add event timestamps to the device data attributes so we can ask things like was there motion in the last hour, when did the temp last change, etc.
    TODO: Add support for increase|decrease xx% commands
*/
const ohm = require('./ohm.min.js');
// const wtn = require('./wtn.js');
const _lodash = require('./lodash.min.js');
const math = require('./math.min.js');
const pluralize = require('./pluralize.js');

const millisecondsTo = {
    millisecond: 1,
    second: 1000,
    minute: 60000,
    hour: 3600000,
    day: 86400000,
    week: 604800000,
    percent: 1,
    level: 1
};

class Parser {
    constructor(esClass) {
        this.attributes = esClass.alexaHandler.attributes;
        this.allowPersonality = esClass.allowPersonality;
        this.followupMode = esClass.followupMode;
        this.response = esClass.alexaHandler.response;
        this.esData = esClass.esData;
        this.hereData = esClass.hereData;
        this.alexaHandler = esClass.alexaHandler;
        this.emit = esClass.alexaHandler.emit;
        this.event = esClass.alexaHandler.event;
        this.respMap = esClass.respStrings;
        this.utils = esClass.utils;
        this.devId = esClass.alexaHandler.handler.theId;
        this.stHost = esClass.stHost;
        this.stPort = esClass.stPort;
        this.stPath = esClass.stPath;
        this.stAppID = esClass.stAppID;
        this.devName = esClass.devName;
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.imgPathUrl = esClass.imgPathUrl;
        this.skillName = 'EchoSistant Smart Home';
        this.echoHasDisplay = esClass.echoHasDisplay;
        this.quietMode = esClass.esData.settings.quietMode === true;
    }

    devNameListBuilder(devsObj) {
        let devs = devsObj.map(dev => dev.device).sort().join(', ');
        if (Object.keys(devsObj).length > 1) {
            var pos = devs.lastIndexOf(',');
            devs = devs.substring(0, pos) + ', and ' + devs.substring(pos + 2);
        }
        return devs;
    }

    stateTense(devState, cap) {
        switch (devState) {
            case 'lock':
            case 'unlock':
            case 'open':
                return devState + 'ed';
            case 'close':
                return devState + 'd';
            default:
                return devState;
        }
    }

    sendStatusRoom(cmd) {
        let skipCmds = ['lock'];
        return !_lodash.includes(skipCmds, cmd);
    }

    aggreType(cap) {
        switch (cap) {
            case 'temperature':
                return 'temp';
            case 'humidity':
                return 'percent';
            default:
                return cap;
        }
    }

    aggreStateData(type, data, retState = false) {
        if (type && data) {
            let res;
            switch (type) {
                case 'water':
                    res = !retState ? _lodash.includes(data, 'wet').toString() === 'true' : 'wet';
                    break;
                case 'sound':
                case 'motion':
                    res = !retState ? _lodash.includes(data, 'active').toString() === 'true' : 'active';
                    break;
                case 'temp':
                case 'percent':
                case 'average':
                    res = data.length ? math.round(math.mean(data), 1).toString() + this.valueType(type) : data + this.valueType(type);
                    break;
            }
            return res;
        }
    }

    valueType(type) {
        if (type) {
            switch (type) {
                case 'temp':
                    return '\xB0' + this.esData.locData.temp_scale;
                case 'percent':
                    return '%';
                default:
                    return '';
            }
        }
    }

    statusRespType(context) {
        switch (context) {
            case 'which|are':
            case 'which':
            case 'tell':
                return 'verbose';

            case 'what|is':
                return 'groupRoom';
            case 'is':
            case 'are':
                return 'bool';
        }
    }

    processStatus(cap, devData, theIntent) {
        console.log('cap: ' + cap, 'devData: ' + devData);
        let output = '';
        let capDevices = [];
        _lodash.forEach(_lodash.uniqBy(devData, 'theId'), function(dev) {
            capDevices.push(dev);
        });
        if (capDevices.length >= 1) {
            var capRooms = _lodash.uniqBy(capDevices.map(cd => cd.room), 'room');
            var capRoom = capRooms.length <= 1 ? capRooms[0] : theIntent;
            var cmdContext = capDevices[0].context;
            var addRoom = !capDevices[0].deviceCmd === true;
            var contextType = this.statusRespType(cmdContext);
            var respItems;
            switch (contextType) {
                case 'verbose':
                    console.log('verbose status');
                    break;
                case 'groupRoom':
                    console.log('groupRoom status');
                    var avgStr = capDevices.length > 1 ? 'average ' : '';
                    var stateValues = this.aggreStateData(this.aggreType(cap), capDevices.map(d => d.state).filter(d => d !== undefined));
                    var respItems = ['The ' + avgStr + cap + ' in the ' + capRoom + ' is ' + stateValues, "It's currently an " + avgStr + cap + ' of ' + stateValues + ' in the ' + capRoom];
                    output += this.utils.getRandomItem(respItems);
                    break;
                case 'bool':
                    console.log('bool status');
                    var stateValues = this.aggreStateData(this.aggreType(cap), capDevices.map(d => d.state).filter(d => d !== undefined));
                    var boolPrefix = stateValues === true ? 'Yes, ' : 'No, ';
                    switch (cap) {
                        case 'motion':
                        case 'sound':
                            var boolDesc = stateValues === true ? 'is ' : 'is not any ';
                            var boolRoomDesc = addRoom ? ' in the ' + capRoom : '';
                            respItems = ['There ' + boolDesc + ' ' + cap + boolRoomDesc, 'There ' + boolDesc + 'currently ' + cap + boolRoomDesc, 'At the moment there ' + boolDesc + 'currently ' + cap + boolRoomDesc];
                            break;
                        default:
                            var boolDesc = stateValues === true ? 'is ' : 'is not ';
                            var boolRoomDesc = addRoom ? ' in the ' + capRoom : '';
                            respItems = ['There ' + boolDesc + ' ' + cap + boolRoomDesc, 'There ' + boolDesc + 'currently ' + cap + boolRoomDesc, 'At the moment there ' + boolDesc + ' ' + cap + boolRoomDesc];
                            break;
                    }
                    output += boolPrefix + ' ' + this.utils.getRandomItem(respItems);
                    break;
            }
        }
        return output;
    }

    getStatusResp(statusData, theIntent) {
        // console.log('getStatusResp(statusData):', JSON.stringify(statusData));
        // TODO: Debug 'is the front door open'
        let status = '';
        let matchedStr = '';
        let unmatchedStr = '';
        let yesPrefix = false;
        let noPrefix = false;
        let yesCaps = [];
        let noCaps = [];
        let yesResps = [];
        let noResps = [];
        if (statusData === undefined || statusData.length < 1) {
            return status;
        }
        let cmdMatchGroup = _lodash.groupBy(statusData, function(dev) {
            return dev.cmd && dev.state && (dev.cmd === dev.state || dev.state.includes(dev.cmd) || dev.state.match('\\b' + dev.cmd + '(?:(?:es|s|ed)?)\\b'));
        });
        // console.log('cmdMatchGroup: ', cmdMatchGroup);
        if (cmdMatchGroup && Object.keys(cmdMatchGroup).length >= 1) {
            if (cmdMatchGroup.true && cmdMatchGroup.true.length >= 1) {
                let cmdGroup = _lodash.groupBy(cmdMatchGroup.true, 'cmd');
                // let cmdCnt = 0;
                let yesStatus = '';
                for (let cmd in cmdGroup) {
                    // cmdCnt++;
                    // let lastCmd = cmdCnt === Object.keys(cmdGroup).length;
                    let capGroup = _lodash.groupBy(cmdGroup[cmd], 'cap');
                    let capsFound = Object.keys(capGroup).length;
                    let cmdDevCnt = 0;
                    let capCnt = 0;
                    for (let cap in capGroup) {
                        capCnt++;
                        yesCaps.push(cap + ':' + cmd);
                        let capDevices = [];
                        let lastCap = capsFound === capCnt;
                        _lodash.forEach(_lodash.uniqBy(capGroup[cap], 'theId'), function(dev) {
                            capDevices.push(dev);
                        });
                        let isAllDevices = capDevices.length === Object.keys(capGroup[cap]).length;
                        if (capDevices.length >= 1) {
                            cmdDevCnt = cmdDevCnt + capDevices.length;

                            let showRoom = this.sendStatusRoom(cmd);
                            let capRoom = showRoom ? capDevices[0].room || undefined : '';
                            let cmdContext = capDevices[0].context;
                            let verboseDevs = ['which', 'tell'].includes(cmdContext);
                            let boolDevResp = ['is', 'are'].includes(cmdContext);
                            let cmdTense = this.stateTense(cmd, cap);
                            let devList = this.devNameListBuilder(capDevices);
                            console.log('cmdContext: (' + cmdContext + ') | verboseDevs: (' + verboseDevs, ') | boolDevResp: (' + boolDevResp + ') | showRoom: (' + showRoom + ') | isAllDevices: (' + isAllDevices + ') | cmdDevCnt: (' + cmdDevCnt + ') | cap: (' + cap, ') | cmd: (' + cmd + ':' + cmdTense + ') | capRoom: (' + capRoom + ')');

                            if (verboseDevs || capDevices.length >= 4) {
                                // NOTE: If the are more than 3 devices per cmd/cap then only return the count of the devices instead of listing each.
                                if (verboseDevs) {
                                    yesStatus += 'The ';
                                    yesStatus += devList + ' ' + pluralize(cap, cmdDevCnt) + ' are ' + (isAllDevices ? 'all ' : '') + cmdTense;
                                } else {
                                    if (boolDevResp && !yesPrefix) {
                                        yesStatus += 'Yes, ';
                                        yesPrefix = true;
                                    }
                                    // if (isAllDevices) {
                                    //     yesStatus += 'All ' + pluralize(cap, cmdDevCnt, true) + ' are ' + cmdTense;
                                    // } else {
                                    yesStatus += status === '' ? 'There are ' : '';
                                    yesStatus += pluralize(cap, cmdDevCnt, true) + ' that are ' + cmdTense;
                                    // }
                                }
                                yesStatus += capRoom ? ' in the ' + capRoom : '';
                            } else {
                                if (boolDevResp && !yesPrefix) {
                                    yesStatus += 'Yes, ';
                                    yesPrefix = true;
                                }
                                yesStatus += 'The ';
                                yesStatus += devList;
                                if (lastCap) {
                                    if (!cmdDevCnt > 1) {
                                        yesStatus += pluralize(cap, cmdDevCnt) + ' is ' + cmdTense;
                                    } else {
                                        if (capDevices.map(dev => dev.device).sort().join(', ').match('\\b' + cap + '(?:(?:es|s)?)\\b', 'gi')) {
                                            // NOTE: If the device name already contains the plural version of the cap then leave it be.
                                            yesStatus += (cmdDevCnt > 1 ? ' are ' : ' is ') + cmdTense;
                                        } else {
                                            yesStatus += ' ' + pluralize(cap, cmdDevCnt) + (cmdDevCnt > 1 ? ' are ' : ' is ') + cmdTense;
                                        }
                                        yesStatus += capRoom ? ' in the ' + capRoom : '';
                                    }
                                } else {
                                    yesStatus += ', ';
                                }
                            }
                        }
                    }
                    yesResps.push(yesStatus);
                    yesStatus = '';
                }
            }
            if (cmdMatchGroup.null) {
                let cmdGroup = _lodash.groupBy(cmdMatchGroup.null, 'cmd');
                let noStatus = '';
                for (let cmd in cmdGroup) {
                    let capGroup = _lodash.groupBy(cmdGroup[cmd], 'cap');
                    for (let cap in capGroup) {
                        let capStr = cap + ':' + cmd;
                        // console.log('yesCaps: ' + yesCaps + ' | skip: (' + _lodash.includes(yesCaps, capStr) + ') | [' + capStr + ']');
                        if (_lodash.includes(yesCaps, capStr) === false) {
                            noCaps.push(capStr);
                            let capDevices = [];
                            _lodash.forEach(_lodash.uniqBy(capGroup[cap], 'theId'), function(dev) {
                                capDevices.push(dev);
                            });
                            let showRoom = this.sendStatusRoom(cmd) === true;
                            let capRoom = showRoom ? capDevices[0].room || undefined : '';
                            let cmdContext = capDevices[0].context;
                            // TODO: Add support for verbose device list on devices that don't match
                            // let verboseDevs = cmdContext === 'which' || cmdContext === 'tell';
                            let boolDevResp = cmdContext === 'is' || cmdContext === 'are';
                            let cmdTense = this.stateTense(cmd, cap);
                            let room = capRoom && capRoom.length ? ' in the ' + capRoom : '';
                            if (boolDevResp && !noPrefix) {
                                noStatus += 'No, ';
                                noPrefix = true;
                            }
                            noStatus += this.utils.getRandomItem(["I don't see any ", "I wasn't able to find any ", 'there are no ']);
                            noStatus += pluralize(cap, capDevices.length);
                            noStatus += room.length ? ' ' + cmdTense + room : 'that are ' + cmdTense;
                        }
                    }
                    if (noStatus.length > 0) {
                        noResps.push(noStatus);
                        noStatus = '';
                    }
                }
            }
            if (Object.keys(cmdMatchGroup).length === 1 && Object.keys(cmdMatchGroup)[0] === '') {
                let yesStatus = '';
                let capGroup = _lodash.groupBy(cmdMatchGroup[Object.keys(cmdMatchGroup)[0]], 'cap');
                if (Object.keys(capGroup).length) {
                    let capItem = Object.keys(capGroup)[0];
                    yesStatus += this.processStatus(capItem, capGroup[capItem], theIntent);
                }
                if (yesStatus.length > 0) {
                    yesResps.push(yesStatus);
                    yesStatus = '';
                }
            }
        } else {
            unmatchedStr = this.utils.getRandomItem(["I couldn't find any devices that matched the state you were asking for!", "I wasn't able to find any devices matching the state you requested!", 'No devices were found that match your request!']);
        }
        for (let i = 0; i < yesResps.length; i++) {
            let last = i + 1 === yesResps.length;
            matchedStr += yesResps[i];
            matchedStr += !last ? ', and ' : '';
        }
        for (let i = 0; i < noResps.length; i++) {
            let last = i + 1 === noResps.length;
            unmatchedStr += noResps[i];
            unmatchedStr += !last ? ', and ' : '';
        }
        status += matchedStr;
        status += matchedStr.length && unmatchedStr.length ? ', and ' : '';
        status += unmatchedStr;
        status += '.';
        console.log('statusResp: ' + status);
        return status;
    }

    entries(obj) {
        var ownProps = Object.keys(obj),
            i = ownProps.length,
            resArray = new Array(i); // preallocate the Array
        while (i--) {
            resArray[i] = [ownProps[i], obj[ownProps[i]]];
        }
        return resArray;
    }

    findDevices() {
        console.log('findDevices()');
        let defaultIntent = false;
        let wasIssue = false;
        const allRooms = [];
        this.attributes.speechOutput = '';
        this.attributes.repromptSpeech = '';

        const parseCaps = theCaps => {
            const results = [];
            theCaps = this.utils.cleanString(theCaps).replace(new RegExp(allRooms.map(theRoom => theRoom.theName).join('|'), 'gi'), '').replace(/(\|\s)|(\|\|)/gi, '|');
            theCaps = (theCaps + '|' + theCaps.replace(/(\|)|(\s+)/g, '|') + '|').replace('battery|', 'battery|batteries|').replace('nestreport|', 'nestreport|nest report|').replace('temperature|', 'temperature|temps|temp|').split('|').filter((theCaps, index, self) => self.findIndex(theCap => theCap === theCaps && theCaps !== '') === index);
            if (theCaps !== undefined) {
                if (theParsedCommand.match('\\b' + theCaps.join('(?:(es|s|ed)?)\\b|\\b') + '(?:(es|s|ed)?)\\b') !== null) {
                    for (const theCap of theCaps) {
                        results.push(
                            Object({
                                theName: theCap,
                                theType: 'cap',
                                theId: theCap
                            })
                        );
                    }
                }
            }
            return results;
        };

        const parseCmds = theCmds => {
            const results = [];
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('level'))) {
                theCmds.push('raise');
                theCmds.push('lower');
            }
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('open'))) {
                theCmds.push('opened');
            }
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('close'))) {
                theCmds.push('closed');
            }
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('lock'))) {
                theCmds.push('locked');
            }
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('unlock'))) {
                theCmds.push('unlocked');
            }
            if (theCmds.some(theCmd => theCmd.toLowerCase().match('updateNestReportData'))) {
                theCmds.push('nest report');
            }
            for (const theCmd of theCmds) {
                const cleanedCmd = this.utils.cleanString(theCmd.replace(/(?:set|get){1}[A-Z]/g, '').trim().replace(/([a-z])([A-Z])/g, '$1 $2'));
                if (theParsedCommand.match('\\b' + cleanedCmd + '(?:(es|s)?)\\b') !== null) {
                    results.push(
                        Object({
                            theName: cleanedCmd,
                            theType: 'cmd',
                            theId: theCmd
                        })
                    );
                }
            }
            return results;
        };

        const get_bigrams = string => {
            let i;
            let j;
            let ref;
            let s;
            let v;
            s = string.toLowerCase();
            v = new Array(s.length - 1);
            for (i = j = 0, ref = v.length; j <= ref; i = j += 1) {
                v[i] = s.slice(i, i + 2);
            }
            return v;
        };

        const string_similarity = (str1, str2) => {
            let hit_count;
            let j;
            let k;
            let len;
            let len1;
            let pairs1;
            let pairs2;
            let union;
            let x;
            let y;
            if (str1.length > 0 && str2.length > 0) {
                pairs1 = get_bigrams(str1);
                pairs2 = get_bigrams(str2);
                union = pairs1.length + pairs2.length;
                hit_count = 0;
                for (j = 0, len = pairs1.length; j < len; j++) {
                    x = pairs1[j];
                    for (k = 0, len1 = pairs2.length; k < len1; k++) {
                        y = pairs2[k];
                        if (x === y) {
                            hit_count++;
                        }
                    }
                }
                if (hit_count > 0) {
                    return 2.0 * hit_count / union;
                }
            }
            return 0.0;
        };

        const parseName = theName => {
            theName = this.utils.cleanString(theName);
            if (string_similarity(theParsedCommand, theName) > 0.33) {
                return '~' + theName;
            }
            return theName;
        };

        let theCommand;
        const mainIntent = this.event.request.intent.name;
        let theIntent;
        if (this.attributes.commandBeforeHere !== undefined && this.hereData.echoDevices !== undefined && this.hereData.echoDevices[this.devId] !== undefined && this.hereData.echoDevices[this.devId]['room'] !== undefined) {
            theCommand = this.utils.cleanString(this.attributes.commandBeforeHere.replace('%', ' percent'));
            theIntent = this.utils.cleanString(this.hereData.echoDevices[this.devId]['room'].split(/(?=[A-Z]+[^A-Z]?)/).join(' '));
            this.attributes.commandBeforeHere = undefined; // Temporary Fix for Here repeating commands
        } else {
            theCommand = this.utils.cleanString(this.event.request.intent.slots.ttstext.value.replace('%', ' percent'));
            theIntent = this.utils.cleanString(this.event.request.intent.name.split(/(?=[A-Z]+[^A-Z]?)/).join(' '));
            if (theIntent === 'here' && this.hereData.echoDevices !== undefined && this.hereData.echoDevices[this.devId] !== undefined && this.hereData.echoDevices[this.devId]['room'] !== undefined) {
                theIntent = this.utils.cleanString(this.hereData.echoDevices[this.devId]['room'].split(/(?=[A-Z]+[^A-Z]?)/).join(' '));
            }
        }
        this.attributes.previousCommand = theCommand;
        // const testModeActive = theHandler.esData.testModeActive;
        // console.log("testModeActive: " + testModeActive);
        let theParsedCommand = theCommand; // wtn(theCommand);
        // Data from the dynamobd
        const devData = this.esData.devData;
        const locData = this.esData.locData;
        const modesRoutinesPass = [];

        for (const [keys, values] of this.entries(locData)) {
            switch (keys) {
                case 'availStModes':
                case 'availStRoutines':
                    for (const theItem of values) {
                        if (parseName(theItem.name).indexOf('~') !== -1) {
                            modesRoutinesPass.push({
                                theName: this.utils.cleanString(theItem.name),
                                theType: theItem.type.toLowerCase(),
                                theId: theItem.id
                            });
                        }
                    }
                    break;
                case 'availableRooms':
                    for (const theRoom of values) {
                        allRooms.push({
                            theName: this.utils.cleanString(theRoom.name),
                            theType: 'room',
                            index: theParsedCommand.length,
                            theId: theRoom.id
                        });
                    }
                    break;
                case 'securityPINs':
                    for (const thePass of values.master) {
                        modesRoutinesPass.push({
                            theName: this.utils.cleanString(thePass.toString()),
                            theType: 'passwords',
                            theId: thePass
                        });
                    }
                    break;
            }
        }

        if (allRooms.some(theRoom => theRoom.theName === theIntent)) {
            if (theCommand.match('\\b' + theIntent + '\\b') === null) {
                // theParsedCommand += ' ' + theIntent; // Add the intent room if its a real room and not already in the command
            }
        } else {
            defaultIntent = true;
        }

        const allCmds = [];
        const allCaps = [];
        const shortCuts = [];
        const theDevices = [];

        for (const theDevice of devData) {
            const theName = parseName(theDevice.label);
            const caps = parseCaps(theDevice.capabilities);
            const rooms = this.utils.cleanString(theDevice.rooms).split('|');
            const cmds = parseCmds(theDevice.commands);
            if (caps.length !== 0 || cmds.length !== 0 || theName.indexOf('~') !== -1) {
                if (theDevice.capabilities.includes('Shortcut') && theParsedCommand.match(theName.replace('~', '')) !== null) {
                    if (((!defaultIntent ? theIntent + ' ' : '') + theParsedCommand).match('\\b' + rooms.join('\\b|\\b') + '\\b') !== null) {
                        const theRoom = allRooms.filter(theRooms => rooms.includes(theRooms.theName)) || [];
                        shortCuts.push({
                            theName: theName.replace('~', ''),
                            theId: theRoom[0].theId.toString() + ':' + theDevice.deviceId,
                            theType: 'shortcut'
                        });
                    }
                } else {
                    if (caps.length !== 0) {
                        allCaps.push(caps);
                    }
                    if (cmds.length !== 0) {
                        allCmds.push(cmds);
                    }
                    theDevices.push({
                        theName: theName.replace('~', ''),
                        theType: 'device',
                        rooms: rooms.map(room => room),
                        theId: theDevice.deviceId,
                        cmds: cmds.length !== 0 ? cmds.map(cmd => cmd.theName) : [],
                        caps: caps.length !== 0 ? caps.map(cap => cap.theName) : [],
                        hideFromGroupCmds: theDevice.hideFromGroupCmds,
                        type: theDevice.type,
                        states: theDevice.states
                    });
                }
            }
        }

        const foundCapsAndCmds = allCmds
            .concat(allCaps)
            .reduce((acc, curr) => {
                return acc.concat(curr);
            }, [])
            .filter((theItems, index, self) => self.findIndex(theItem => theItem.theName === theItems.theName && theItem.theType === theItems.theType && theItem.theId === theItems.theId && theItem.index === theItems.index) === index)
            .filter(theItem => theItem.theName !== '');

        let allColors = [];
        if (foundCapsAndCmds.includes('color')) {
            allColors = this.utils.getColorData();
        } else {
            allColors = this.utils.getColorData().filter(theItem => theParsedCommand.match(theItem.theName));
        }

        const allItems = []
            .concat(theDevices.map(theItem => theItem.theName), modesRoutinesPass.map(theItem => theItem.theName), shortCuts.map(theItem => theItem.theName), allRooms.map(theItem => theItem.theName), foundCapsAndCmds.map(theItem => theItem.theName), allColors.map(theItem => theItem.theName), this.utils.getParserItems().map(theItem => theItem.theName))
            .filter((theItems, index, self) => self.findIndex(theItem => theItem === theItems) === index);

        const searchText = theParsedCommand.match(new RegExp('(\\d+|' + allItems.join('|').replace(/(\|\s)|(\|\|)/gi, '|') + ')', 'g')) || [];

        const parserDevices = theDevices.map(theDevice => theDevice.theName).join(` " | "`);
        const parserShortcuts = shortCuts.map(theShortcut => theShortcut.theName).join(` " | "`);
        const parserModes = modesRoutinesPass.filter(theModes => theModes.theType === 'mode').map(theMode => theMode.theName).join(` " | "`);
        const parserRoutines = modesRoutinesPass.filter(theRoutines => theRoutines.theType === 'routine').map(theRoutine => theRoutine.theName).join(` " | "`);
        const parserCmds = foundCapsAndCmds.filter(theCmds => theCmds.theType === 'cmd').map(theCmd => theCmd.theName).join(` " | "`);
        const parserCaps = foundCapsAndCmds.filter(theCmds => theCmds.theType === 'cap').map(theCap => theCap.theName).join(` " | "`);
        const parserRooms = allRooms.map(theRoom => theRoom.theName).join(` " | "`);
        const parserColors = allColors.map(theColor => theColor.theName).join(` " | "`);
        const parserPasswords = modesRoutinesPass.filter(thePasses => thePasses.theType === 'passwords').map(thePass => thePass.theName).join(` " | "`);
        const parserStatusPhrases = this.utils.getParserItems().filter(theItems => theItems.theType === 'status' && theParsedCommand.match('\\b' + theItems.theName + '\\b') !== null).map(theStatus => theStatus.theName).sort((a, b) => b.length - a.length || a.localeCompare(b)).join(` " | "`);

        console.log('searchText: ' + searchText);

        const g = ohm.grammars(`
        Parser1 {
            Requests = (command | shortcut | mode | alarm | routine)+
            command = cmdAttr? (devOrCap+ status? cmdsOrColorsOrAmount? | cmdsOrColorsOrAmount? status? devOrCap+) cmdAttr?
            shortcut = rooms? amount? rooms? shortcuts rooms? amount? rooms?
            mode = attr? modes attr?
            alarm = attr? alarms attr?
            routine = attr? routines attr?
            devOrCap = devOrRoomAndCap | caps
            devOrRoomAndCap = devices | roomAndCap
            roomAndCap = rooms caps
            cmdsOrColorsOrAmount = cmds | colors | amount

            cmdAttr = (status | all | amount | passwords | rooms)+
            attr = (status | amount)+

            amount = level | number
            number = digit+ space (delay | level?)

            delay = ("minute " | "minutes " | "week " | "weeks " | "day " | "days " | "hour " | "hours " | "second " | "seconds " | "millisecond " | "milliseconds ")
            level = ("level " | "levels " | "degree " | "degrees " | "percent " | "percents " | "percentages " | "brightness ")
            alarms = ("disarm " | "armed stay " | "armed away " | "armed ")

            passwords = (${parserPasswords.length !== 0 ? '"' + parserPasswords + ' "' : '"  "'})
            shortcuts = (${parserShortcuts.length !== 0 ? '"' + parserShortcuts + ' "' : '"  "'})
            modes = (${parserModes.length !== 0 ? '"' + parserModes + ' "' : '"  "'})
            routines = (${parserRoutines.length !== 0 ? '"' + parserRoutines + ' "' : '"  "'})
            devices = (${parserDevices.length !== 0 ? '"' + parserDevices + ' "' : '"  "'})
            cmds = (${parserCmds.length !== 0 ? '"' + parserCmds + ' "' : '"  "'})
            caps = (${parserCaps.length !== 0 ? '"' + parserCaps + ' "' : '"  "'})
            rooms = (${parserRooms.length !== 0 ? '"' + parserRooms + ' "' : '"  "'})
            status = (${parserStatusPhrases.length !== 0 ? '"' + parserStatusPhrases + ' "' : '"  "'})
            colors = (${parserColors.length !== 0 ? '"' + parserColors + ' "' : '"  "'})
            all = ("all " | "every " | "everything ")
        }
        Parser2 <: Parser1 {
            command := cmdAttr? (devOrCap status? cmdsOrColorsOrAmount? | cmdsOrColorsOrAmount? status? devOrCap) cmdAttr?
        }
    `);

        const getRequest = (children, results) => {
            for (const child of children) {
                if (child.matchLength !== 0) {
                    if (child.children[0].constructor.name === 'TerminalNode') {
                        if (results[child.ctorName] === undefined) {
                            results[child.ctorName] = child.children[0].primitiveValue.trim();
                        } else {
                            if (child.ctorName === 'digit') {
                                results[child.ctorName] += child.children[0].primitiveValue.trim();
                            } else {
                                results[child.ctorName] += '|' + child.children[0].primitiveValue.trim();
                            }
                        }
                    } else {
                        getRequest(child.children, results);
                    }
                }
            }
            return results;
        };

        const parseCommands = children => {
            const commands = [];
            for (const child of children) {
                commands.push(getRequest(child.children, {}));
            }
            return commands;
        };

        const updateState = (theCmd, theCap) => {
            const results = {};
            if (theCmd !== '') {
                switch (theCmd) {
                    case 'lock':
                    case 'locked':
                        results['theState'] = 'lock';
                        results['theCap'] = 'lock';
                        break;
                    case 'unlock':
                    case 'unlocked':
                        results['theState'] = 'lock';
                        results['theCap'] = 'lock';
                        break;
                    case 'open':
                    case 'opened':
                        results['theState'] = 'contact';
                        results['theCap'] = 'door';
                        break;
                    case 'close':
                    case 'closed':
                        results['theState'] = 'contact';
                        results['theCap'] = 'door';
                        break;
                    case 'on':
                    case 'off':
                        results['theState'] = 'switch';
                        results['theCap'] = 'light';
                        break;
                }
            }
            if (theCap.length > 0) {
                for (const cap of theCap) {
                    switch (cap) {
                        case 'battery':
                            results['theState'] = 'battery';
                            break;
                        case 'temperature':
                            results['theState'] = 'temperature';
                            break;
                        case 'thermostat':
                            results['theState'] = 'temperature';
                            results['theCap'] = 'temperature';
                            break;
                        case 'lock':
                            results['theState'] = 'lock';
                            results['theCap'] = 'lock';
                            break;
                        case 'humidity':
                            results['theState'] = 'humidity';
                            break;
                        case 'motion':
                            results['theState'] = 'motion';
                        case 'sound':
                            results['theState'] = 'sound';
                            break;
                        case 'unlock':
                            results['theState'] = 'lock';
                            results['theCap'] = 'lock';
                            break;
                        case 'open':
                            results['theState'] = 'contact';
                            results['theCap'] = 'door';
                            break;
                        case 'close':
                            results['theState'] = 'contact';
                            results['theCap'] = 'door';
                            break;
                        case 'door':
                            results['theCap'] = 'door';
                            break;
                        case 'light':
                        case 'outlet':
                        case 'fan':
                            results['theState'] = 'switch';
                            break;
                        case 'vent':
                            results['theState'] = 'switch';
                            results['theCap'] = 'vent';
                            break;
                    }
                }
            }
            return results;
        };

        const capCmdTranslator = (theCap, theCmd) => {
            switch (theCap) {
                case 'vent':
                    switch (theCmd) {
                        case 'open':
                            return 'on';
                        case 'close':
                            return 'off';
                        default:
                            return theCmd;
                    }
                case 'nestreport':
                    return 'updateNestReportData';
                default:
                    return theCmd;
            }
        };
        const shrtCmds = [];
        const shmCmd = [];
        const modeCmd = [];
        const routineCmd = [];
        const devicesFound = [];

        let m = g.Parser1.match((searchText.length && searchText !== 'null' ? searchText.join(' ') : '') + ' ');
        if (m.failed()) {
            m = g.Parser2.match((searchText.length && searchText !== 'null' ? searchText.join(' ') : '') + ' ');
        }
        if (m.succeeded()) {
            const commands = parseCommands(m._cst.children[0].children);
            for (const eachCommand of commands) {
                const theFoundDevices = eachCommand.devices !== undefined ? eachCommand.devices.split('|') : [];
                const theCmd = eachCommand.cmds || '';
                let theFoundDevice = theDevices.filter(eachDevice => theFoundDevices.includes(eachDevice.theName));
                let theCap = eachCommand.caps !== undefined ? eachCommand.caps.replace('batteries', 'battery').replace('nest report', 'nestreport').replace(/temps?/, 'temperature').split('|') : [];
                let theState = updateState(theCmd, theCap);
                if (theState['theCap'] !== undefined) {
                    theCap = [theState['theCap']];
                }
                theState = theState['theState'];
                if (theState !== '' && theFoundDevice.length !== 0) {
                    theFoundDevice = theDevices.filter(eachDevice => {
                        let similarity = string_similarity(eachDevice.theName.replace(theCap, '').trim(), theFoundDevices[0].replace(theCap, '').trim());
                        let otherMatch = (eachDevice.cmds.includes(theCmd) ? eachDevice.states[theState] !== undefined : false);
                        if (similarity > 0.4 && otherMatch) { return eachDevice; }
                    });
                }

                let theDelay = '0';
                let theLevel = '';

                const theAmount = eachCommand.digit || 0;
                if (theAmount !== 0) {
                    theDelay = eachCommand.delay !== undefined ? Math.round(Number(theAmount) * millisecondsTo[eachCommand.delay] / millisecondsTo.second * 100 / 100).toString() : '0';
                    theLevel = 'setLevel';
                }

                const theStatus = eachCommand.status || '';
                const theColor = allColors.filter(theColor => theColor.theName === eachCommand.colors) || [];
                const includeAll = eachCommand.all || '';
                const thePassword = modesRoutinesPass.filter(thePass => thePass.theType === 'passwords' && thePass.theName === eachCommand.digit) || '';
                const theRoom = eachCommand.rooms !== undefined ? eachCommand.rooms : defaultIntent === false ? theIntent : '';
                const theMode = modesRoutinesPass.filter(theMode => theMode.theType === 'mode' && theMode.theName === eachCommand.modes) || [];
                const theRoutine = modesRoutinesPass.filter(theMode => theMode.theType === 'routine' && theMode.theName === eachCommand.routines) || [];
                const theSHM = eachCommand.alarms || '';
                const theShortcut = shortCuts.filter(theCut => theCut.theName === eachCommand.shortcuts) || [];

                let passwordRequired = false;
                if (modesRoutinesPass.filter(thePass => thePass.theType === 'passwords').length !== 0) {
                    passwordRequired = true;
                }

                if (theMode.length !== 0) {
                    modeCmd.push(theMode[0].theId + ':' + theDelay);
                } else if (theRoutine.length !== 0) {
                    routineCmd.push(theRoutine[0].theId + ':' + theDelay);
                } else if (theShortcut.length !== 0) {
                    shrtCmds.push(theShortcut[0].theId + ':' + theDelay);
                } else if (theSHM.length !== 0 && (passwordRequired ? thePassword.length !== 0 : !!true)) {
                    shmCmd.push(theSHM + ':' + theDelay);
                } else {
                    if (theFoundDevice.length === 0) {
                        if (theRoom === '') {
                            theFoundDevice = theDevices.filter(eachDevice => eachDevice.caps.find(cap => theCap.includes(cap)) || (eachDevice.cmds.includes(theCmd) || eachDevice.states[theState] !== undefined));
                        } else if (theLevel !== '0' || theColor.length !== 0) {
                            theFoundDevice = theDevices.filter(eachDevice => eachDevice.rooms.includes(theRoom) && eachDevice.caps.find(cap => theCap.includes(cap)));
                        } else {
                            theFoundDevice = theDevices.filter(eachDevice => eachDevice.rooms.includes(theRoom) && eachDevice.caps.find(cap => theCap.includes(cap)) && eachDevice.cmds.includes(theCmd));
                        }
                    }
                    for (const dev of theFoundDevice) {
                        if (includeAll === '' ? dev.hideFromGroupCmds === false : !!true) {
                            // if (theCap.length === 0) {
                            //   theCap = getCap(dev, theCmd);
                            // }
                            devicesFound.push({
                                device: dev.theName,
                                theId: dev.theId,
                                cap: theCap,
                                cmd: theColor.length !== 0 ? 'setColor' : theLevel !== '' ? theLevel : capCmdTranslator(theCap[0], theCmd),
                                delay: theDelay,
                                level: theColor.length !== 0 ? theColor[0].theId : theAmount,
                                context: theStatus,
                                room: dev.rooms,
                                state: dev.states[theState]
                            });
                        }
                    }
                }
            }
        } else {
            this.attributes.speechOutput += "I appologize, but I wasn't able to find a match for your request";
            wasIssue = true;
            console.log(m.message);
        }
        const appCmds = [];
        const devCmds = devicesFound.filter(theDevice => theDevice.context === '').reduce((acc, curr) => {
            const theItem = curr['cmd'] + ':' + curr['delay'] + ':' + curr['cap'] + ':' + curr['level'];
            acc[theItem] = acc[theItem] || [];
            acc[theItem].push(curr.theId);
            return acc;
        }, {});

        var status = '';
        status = this.getStatusResp(devicesFound.filter(theDevice => theDevice.context !== '').map(theDevice => ({
            device: theDevice.device,
            theId: theDevice.theId,
            deviceCmd: !!(devicesFound.filter(theDevice => theDevice.context !== '').length <= 1 && theDevice.cmd === ''),
            cap: theDevice.cap,
            cmd: theDevice.cmd,
            context: theDevice.context,
            room: theDevice.room,
            state: theDevice.state
        })), theIntent);
        if (status === '' && !(Object.keys(devCmds).length || appCmds.length || shmCmd.length || shrtCmds.length || modeCmd.length || routineCmd.length)) {
            wasIssue = true;
            status += "I was unable to find a suitable match to any devices or attributes for the following request, " + theCommand;
        }

        let cmdOkToSend = !wasIssue && !!(Object.keys(devCmds).length || appCmds.length || shmCmd.length || shrtCmds.length || modeCmd.length || routineCmd.length);
        this.attributes.speechOutput += status;
        this.attributes.speechOutput += status !== '' && cmdOkToSend === true ? ' and, ' : '';

        if (cmdOkToSend === true) {
            const processData = JSON.stringify({
                theIntent: mainIntent,
                cmdTypes: {
                    appCmds: appCmds,
                    devCmds: devCmds,
                    modeCmd: modeCmd,
                    shrtCmds: shrtCmds,
                    routineCmd: routineCmd,
                    shmCmd: shmCmd
                },
                echoId: this.event.context.System.device.deviceId,
                userId: this.event.session.user.userId,
                requestId: this.event.request.requestId,
                sessionId: this.event.session.sessionId,
                theCommand: theCommand,
                setValues: this.esData.settings,
                lambdaInfo: {
                    version: this.appVersion,
                    versionDt: this.appVerDate
                }
            });

            const postHeaders = {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(processData, 'utf8')
            };
            const options = {
                port: this.stPort,
                host: this.stHost,
                path: this.stPath,
                method: 'POST',
                headers: postHeaders
            };
            let self = this;
            this.utils
                .httpRequest(options, processData)
                .then(resp => {
                    console.log('Response from ST: ', resp);
                    let stResp = JSON.parse(resp);
                    self.attributes.speechOutput += stResp.ttsResp;
                    self.esData.settings.followupMode = stResp.followupMode;
                    self.esData.settings.quietMode = stResp.quietMode;
                    if (stResp.wasError === true || stResp.quietMode === true || stResp.appMaint === true || self.esData.settings.followupMode === false) {
                        self.response.speak(this.utils.convSpeechOutput(self.attributes.speechOutput));
                    } else {
                        self.attributes.repromptSpeech = self.utils.getSpeechItem(self.respMap.Followup, 'Default', self.allowPersonality);
                        self.response.speak(this.utils.convSpeechOutput(self.attributes.speechOutput)).listen(this.utils.convSpeechOutput(self.attributes.repromptSpeech));
                    }
                    if (self.echoHasDisplay === true && stResp.showResp) {
                        let tmplt;
                        if (stResp.appMaint === true) {
                            tmplt = self.utils.generateShowCard({
                                skillName: self.skillName,
                                priText: '<font size="3">' + 'SmartApp and Profiles Maintenance in Progress!' + '</font>',
                                secText: '<font size="2">' + 'Please Wait 15 seconds and try your request again.' + '</font>',
                                type: 'body3',
                                token: 'appMaint',
                                sideImage: this.imgPathUrl + 'sad_face.png'
                            });
                        } else if (Object.keys(stResp.showResp).length > 1) {
                            tmplt = self.utils.generateShowCard({
                                skillName: self.skillName,
                                listItems: self.utils.showParseItemsBuilder(stResp.showResp, undefined, true),
                                token: 'showStResp',
                                type: 'list2'
                            });
                        } else if (Object.keys(stResp.showResp).length === 1) {
                            for (let i in stResp.showResp) {
                                tmplt = self.utils.generateShowCard({
                                    skillName: self.skillName,
                                    priText: '<font size="5">' + self.utils.capitalize(stResp.showResp[i].desc) + '</font>',
                                    secText: '<font size="3">' + self.utils.capitalize(self.utils.getActionDesc(i)) + '</font>',
                                    sideImageSize: 'X_SMALL',
                                    sideImage: self.utils.getParseObjImgUrl(stResp.showResp[i].type, i),
                                    type: 'body3'
                                });
                            }
                        } else {
                            tmplt = self.utils.generateShowCard({
                                skillName: self.skillName,
                                priText: self.attributes.speechOutput
                            });
                        }
                        // console.log("showTemplate: ", JSON.stringify(tmplt));
                        self.response.renderTemplate(tmplt);
                    }
                    return self.emit(':responseReady');
                })
                .catch(err => {
                    console.error('ESLogging| ' + err);
                    self.attributes.speechOutput += err;
                    self.response.speak(this.utils.convSpeechOutput(self.attributes.speechOutput));
                    if (self.echoHasDisplay === true) {
                        let template = self.utils.generateShowCard({
                            skillName: self.skillName,
                            priText: self.attributes.speechOutput,
                            type: 'body2',
                            sideImage: this.imgPathUrl + 'crying_face.png'
                        });
                        self.response.renderTemplate(template);
                    }
                    return self.emit(':responseReady');
                });
        } else {
            if (this.attributes.speechOutput === undefined || this.attributes.speechOutput.length < 1) {
                this.attributes.speechOutput = "I appologize, but I wasn't given anything to say. So I made this up!";
            }
            if (this.esData.settings.followupMode === false) {
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput));
            } else {
                this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Followup, 'Default', this.allowPersonality);
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
            }
            console.log(this.attributes.speechOutput);
            if (this.echoHasDisplay === true) {
                let tmplt;
                if (wasIssue === true) {
                    tmplt = this.utils.generateShowCard({
                        skillName: this.skillName,
                        priText: this.attributes.speechOutput,
                        type: 'body2',
                        sideImage: this.imgPathUrl + 'crying_face.png'
                    });
                    this.response.renderTemplate(tmplt);
                } else {
                    tmplt = this.utils.generateShowCard({
                        skillName: this.skillName,
                        priText: this.attributes.speechOutput,
                        type: 'body6'
                    });
                    this.response.renderTemplate(tmplt);
                }
            }
            return this.emit(':responseReady');
        }
    }
}

module.exports.Parser = Parser;