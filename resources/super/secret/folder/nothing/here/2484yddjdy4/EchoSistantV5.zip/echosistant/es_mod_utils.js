'use strict';

const AlexaShowTemplates = new require('../alexa-sdk').templateBuilders;
const TextUtils = new require('../alexa-sdk/lib/utils/textUtils').TextUtils;
const ImageUtils = new require('../alexa-sdk/lib/utils/imageUtils').ImageUtils;
const https = require('https');
// var pluralize = require('./pluralize.js');
class ESUtils {
    constructor(esClass) {
        this.esClass = esClass;
        this.esData = esClass.esData;
        this.imgPathUrl = esClass.imgPathUrl;
        this.analyticsData = esClass.analyticsData;
        this.quietMode = (esClass.esData.settings.quietMode === true);
    }
    get_bigrams(string) {
        let i;
        let j;
        let ref;
        let s;
        let v;
        s = string.toLowerCase();
        v = new Array(s.length - 1);
        for (i = j = 0, ref = v.length; j <= ref; i = j += 1) {
            v[i] = s.slice(i, i + 2);
        }
        return v;
    };
    string_similarity(str1, str2) {
        let hit_count;
        let j;
        let k;
        let len;
        let len1;
        let pairs1;
        let pairs2;
        let union;
        let x;
        let y;
        if (str1.length > 0 && str2.length > 0) {
            pairs1 = this.get_bigrams(str1);
            pairs2 = this.get_bigrams(str2);
            union = pairs1.length + pairs2.length;
            hit_count = 0;
            for (j = 0, len = pairs1.length; j < len; j++) {
                x = pairs1[j];
                for (k = 0, len1 = pairs2.length; k < len1; k++) {
                    y = pairs2[k];
                    if (x === y) {
                        hit_count++;
                    }
                }
            }
            if (hit_count > 0) {
                return (2.0 * hit_count) / union;
            }
        }
        return 0.0;
    };
    addTtsDataToAnalytics(tts, resp, origin) {
        let cData = this.analyticsData;
        if (cData === undefined || cData.collectedData === undefined) {
            cData = {};
            cData['collectedData'] = [];
        }
        cData['collectedData'].push({
            ttstext: tts,
            speechOut: resp,
            origin: origin
        });
        this.analyticsData = cData;
    }
    convSpeechOutput(str) {
        if (this.quietMode === true) { return "<amazon:effect name='whispered'>" + str + "</amazon:effect>"; }
        return str;
    }
    showListItemsBuilder(items, tokenStr, img = undefined) {
        let listOut = [];
        let i = 0;
        for (let item in items) {
            // console.log('ListItem: ' + items[item]);
            let priText = TextUtils.makeRichText('<font size="1">' + this.capitalize(items[item]) + '</font>');
            let secText;
            let terText;
            let itemMap = {
                token: tokenStr === undefined ? undefined : tokenStr + '_' + i,
                image: img === undefined ? undefined : ImageUtils.makeImage(img),
                textContent: TextUtils.makeTextContent(priText, secText, terText)
            };
            listOut.push(itemMap);
            i = i + 1;
        }
        return listOut;
    }
    showSettingItemsBuilder(items, settingItems, tokenStr, img = undefined) {
        let listOut = [];
        for (let item in items) {
            // console.log('SettingItem: ' + items[item]);
            let priText = TextUtils.makeRichText('<font size="1">' + this.capitalize(this.decamelize(item)) + '</font>');
            let secText;
            let terText = TextUtils.makeRichText('<font size="1">' + 'Current: (<u>' + settingItems[this.camelize(item)] + '</u>)</font>');
            let itemMap = {
                token: tokenStr === undefined ? undefined : tokenStr + '_' + Object.keys(items).indexOf(item),
                image: img === undefined ? undefined : ImageUtils.makeImage(img),
                textContent: TextUtils.makeTextContent(priText, secText, terText)
            };
            listOut.push(itemMap);
        }
        return listOut;
    }
    showParseItemsBuilder(items, tokenStr, parseImg = false) {
        // console.log('showParseItemsBuilder(' + JSON.stringify(items) + ', tokenStr: ' + tokenStr + ', parseImg: ' + parseImg);
        const listOut = [];
        for (let item in items) {
            // console.log('ParseItem: ' + JSON.stringify(items[item]));
            let priText;
            let secText;
            let terText = TextUtils.makeRichText(this.capitalize(items[item].desc.toString()));
            let act = item.toString().split(':')[0];
            let actDelay = parseInt(item.toString().split(':')[1]) || 0;
            switch (act) {
                case 'app command':
                    terText = 'AppCommand';
                    break;
                case 'open':
                case 'close':
                case 'lock':
                case 'unlock':
                    priText = actDelay > 0 ? (act.endsWith('e') ? act.substring(0, act.lastIndexOf('e')) : act) + 'ing' : act.endsWith('e') ? act + 'd' : act + 'ed';
                    break;
                case 'on':
                case 'off':
                    priText = actDelay > 0 ? 'Turning ' + act : 'Turned ' + act;
                    break;
                default:
                    priText = act;
                    break;
            }
            priText += actDelay > 0 ? this.getActionDesc(item, true) : '';
            priText = TextUtils.makeRichText(this.capitalize(priText));
            let itemMap = {
                token: tokenStr === undefined ? undefined : tokenStr + '_' + Object.keys(items).indexOf(item),
                image: parseImg === true ? ImageUtils.makeImage(this.getParseObjImgUrl(items[item].type, item)) : '',
                textContent: TextUtils.makeTextContent(priText, secText, terText)
            };
            listOut.push(itemMap);
        }
        return listOut;
    }
    getParseObjImgUrl(actType, action) {
        let imgName;
        action = action.toString().split(':')[0];
        switch (actType) {
            case 'light':
            case 'bulb':
            case 'lamp':
                imgName = action ? 'light_' + action : 'light';
                break;
            case 'door':
                // TODO: How should i add support for normal doors for status
                imgName = action ? 'garage_door_' + action : 'garage_door';
                break;
            case 'garage door':
                imgName = action ? 'garage_door_' + action : 'garage_door';
                break;
            case 'switch':
            case 'fan':
                imgName = action ? actType + '_' + action : actType;
                break;
            default:
                imgName = actType;
                break;
        }
        let url = this.imgPathUrl + imgName + '.png';
        console.log('ImgObj: (actType: ' + actType + ' | action: ' + action + ' | imgName: ' + imgName + ')');
        return url;
    }
    getEsShowBgImg() {
        return this.imgPathUrl + 'echosistant_v5_show_bg.png';
    }
    getActionDesc(action, delayStrOnly = false) {
        let act = action.toString().split(':');
        let str = '';
        str += act[0] && !delayStrOnly ? act[0] : '';
        str += act[1] !== undefined && act[1] > 0 ? ' in ' + this.secondsTimeDesc(act[1]) : '';
        return str;
    }
    getRandomItem(items) {
        return items[Math.floor(Math.random() * items.length)];
    }
    getSpeechItem(itemObj, keyName, attitude) {
        let items = [];
        if (attitude !== false) {
            items = [...new Set([...itemObj[keyName], ...itemObj[keyName + '_Attitude']])];
        } else {
            items = itemObj[keyName];
        }
        return items[Math.floor(Math.random() * items.length)];
    }
    capitalize(str) {
        return str.replace(/\b\w/g, function(l) {
            return l.toUpperCase();
        });
    }
    pluralize(str) {
        return str + (str.endsWith('ch') ? 'es' : 's');
    }
    camelize(str) {
        return str
            .replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
                return index === 0 ? letter.toLowerCase() : letter.toUpperCase();
            })
            .replace(/\s+/g, '');
    }
    decamelize(str, separator) {
        separator = typeof separator === 'undefined' ? ' ' : separator;
        return str.replace(/([a-z\d])([A-Z])/g, '$1' + separator + '$2').replace(/([A-Z]+)([A-Z][a-z\d]+)/g, '$1' + separator + '$2').toLowerCase();
    }
    cleanString(str) {
        if (str instanceof Array) {
            return str.map(theItem => theItem.replace(/[^a-zA-Z0-9 ]/gi, '').replace(/\s{2,}/gi, ' ').toLowerCase().trim()).join('|');
        } else {
            return str === undefined ? '' : str.replace(/[^a-zA-Z0-9 ]/gi, '').replace(/\s{2,}/gi, ' ').toLowerCase().trim();
        }
    }
    cleanSsml(str) {
        return str === undefined ? undefined : str.replace(/\<[^\>]*\>/gi, '');
    }
    generateShowCard(paramsMap) {
        // console.log('generateShowCard(' + funcName + '): ', JSON.stringify(paramsMap));
        let output;
        var builder;
        let title = paramsMap.skillName;
        let priText = TextUtils.makeRichText(paramsMap.priText);
        let secText = paramsMap.secText !== undefined ? TextUtils.makeRichText(paramsMap.secText) : undefined;
        let tertText = paramsMap.terText !== undefined ? TextUtils.makeRichText(paramsMap.terText) : undefined;
        let bgImg = paramsMap.bgImage === undefined ? ImageUtils.makeImage(this.imgPathUrl + 'show_bg/' + (this.esData.locData.showBgWallpaper || 'default') + '.png') : ImageUtils.makeImage(this.imgPathUrl + 'show_bg/' + paramsMap.bgImage);
        let sideImgSize = paramsMap.sideImageSize === undefined ? undefined : paramsMap.sideImageSize;
        let sideImg = paramsMap.sideImage === undefined ? ImageUtils.makeImage(this.imgPathUrl + 'echosistant_v5_512px.png', sideImgSize) : ImageUtils.makeImage(paramsMap.sideImage, sideImgSize);
        let token = paramsMap.token === undefined ? undefined : paramsMap.token;
        let listItems = paramsMap.listItems === undefined ? undefined : paramsMap.listItems;
        let templateStyle = paramsMap.type === undefined ? 'default' : paramsMap.type;
        let showBackBtn = paramsMap.showBackBtn !== true ? 'HIDDEN' : 'VISIBLE';
        switch (templateStyle) {
            case 'body1':
                builder = new AlexaShowTemplates.BodyTemplate1Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setTextContent(priText, secText, tertText).setToken(token).build();
                break;
            case 'body2':
                builder = new AlexaShowTemplates.BodyTemplate2Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
                break;
            case 'body3':
                builder = new AlexaShowTemplates.BodyTemplate3Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
                break;
            case 'body7':
                builder = new AlexaShowTemplates.BodyTemplate7Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
                break;
            case 'list1':
                builder = new AlexaShowTemplates.ListTemplate1Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setListItems(listItems).setToken(token).build();
                break;
            case 'list2':
                builder = new AlexaShowTemplates.ListTemplate2Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setListItems(listItems).setToken(token).build();
                break;
            default:
                builder = new AlexaShowTemplates.BodyTemplate6Builder();
                output = builder.setBackButtonBehavior(showBackBtn).setBackgroundImage(bgImg).setTextContent(priText, secText, tertText).setToken(token).build();
                break;
        }
        return output;
    }
    httpRequest(options, payload) {
        return new Promise((resolve, reject) => {
            const request = https.request(options, response => {
                if (response.statusCode < 200 || response.statusCode > 299) {
                    reject(new Error('Failed to load page, status code: ' + response.statusCode));
                }
                const chunks = [];
                response.on('data', chunk => chunks.push(chunk));
                response.on('end', () => resolve(chunks.join('')));
            });
            request.write(payload);
            request.end();
            request.on('error', err => reject(err));
        });
    }
    logTime(message, startTime) {
        let precision = 3; // 3 decimal places
        let elapsed = process.hrtime(startTime)[1] / 1000000;
        console.log('ESLogging| ', process.hrtime(startTime)[0], 'sec, ', elapsed.toFixed(precision), 'ms - ', message);
        startTime = process.hrtime();
    }
    secondsTimeDesc(sec) {
        var s = {
            year: 31536000,
            month: 2592000,
            week: 604800,
            day: 86400,
            hour: 3600,
            minute: 60,
            second: 1
        };
        let str = '';
        Object.keys(s).forEach(function(key) {
            let v = Math.floor(sec / s[key]);
            if (v > 0) {
                str += v > 0 ? v + ' ' + key + (v > 1 ? 's, ' : ', ') : '';
                sec -= v * s[key];
            }
        });
        console.log(JSON.stringify(this.removeLastComma(str)));
        return this.removeLastComma(str);
    }
    removeLastComma(str) {
        return str.substring(0, str.lastIndexOf(','));
    }
    getColorData() {
        return [
            {
                theName: 'tan',
                theType: 'color',
                theId: '#D2B48C'
            }, {
                theName: 'red',
                theType: 'color',
                theId: '#FF0000'
            }, {
                theName: 'teal',
                theType: 'color',
                theId: '#008080'
            }, {
                theName: 'snow',
                theType: 'color',
                theId: '#FFFAFA'
            }, {
                theName: 'plum',
                theType: 'color',
                theId: '#DDA0DD'
            }, {
                theName: 'pink',
                theType: 'color',
                theId: '#FFC0CB'
            }, {
                theName: 'peru',
                theType: 'color',
                theId: '#CD853F'
            }, {
                theName: 'navy',
                theType: 'color',
                theId: '#000080'
            }, {
                theName: 'lime',
                theType: 'color',
                theId: '#00FF00'
            }, {
                theName: 'gray',
                theType: 'color',
                theId: '#808080'
            }, {
                theName: 'gold',
                theType: 'color',
                theId: '#FFD700'
            }, {
                theName: 'cyan',
                theType: 'color',
                theId: '#00FFFF'
            }, {
                theName: 'blue',
                theType: 'color',
                theId: '#0000FF'
            }, {
                theName: 'aqua',
                theType: 'color',
                theId: '#00FFFF'
            }, {
                theName: 'white',
                theType: 'color',
                theId: '#FFFFFF'
            }, {
                theName: 'wheat',
                theType: 'color',
                theId: '#F5DEB3'
            }, {
                theName: 'olive',
                theType: 'color',
                theId: '#808000'
            }, {
                theName: 'linen',
                theType: 'color',
                theId: '#FAF0E6'
            }, {
                theName: 'khaki',
                theType: 'color',
                theId: '#F0E68C'
            }, {
                theName: 'ivory',
                theType: 'color',
                theId: '#FFFFF0'
            }, {
                theName: 'green',
                theType: 'color',
                theId: '#008000'
            }, {
                theName: 'coral',
                theType: 'color',
                theId: '#FF7F50'
            }, {
                theName: 'brown',
                theType: 'color',
                theId: '#A52A2A'
            }, {
                theName: 'beige',
                theType: 'color',
                theId: '#F5F5DC'
            }, {
                theName: 'azure',
                theType: 'color',
                theId: '#F0FFFF'
            }, {
                theName: 'yellow',
                theType: 'color',
                theId: '#FFFF00'
            }, {
                theName: 'violet',
                theType: 'color',
                theId: '#EE82EE'
            }, {
                theName: 'tomato',
                theType: 'color',
                theId: '#FF6347'
            }, {
                theName: 'silver',
                theType: 'color',
                theId: '#C0C0C0'
            }, {
                theName: 'sienna',
                theType: 'color',
                theId: '#A0522D'
            }, {
                theName: 'salmon',
                theType: 'color',
                theId: '#FA8072'
            }, {
                theName: 'purple',
                theType: 'color',
                theId: '#800080'
            }, {
                theName: 'orchid',
                theType: 'color',
                theId: '#DA70D6'
            }, {
                theName: 'orange',
                theType: 'color',
                theId: '#FFA500'
            }, {
                theName: 'maroon',
                theType: 'color',
                theId: '#800000'
            }, {
                theName: 'indigo',
                theType: 'color',
                theId: '#4B0082'
            }, {
                theName: 'bisque',
                theType: 'color',
                theId: '#FFE4C4'
            }, {
                theName: 'thistle',
                theType: 'color',
                theId: '#D8BFD8'
            }, {
                theName: 'fuchsia',
                theType: 'color',
                theId: '#FF00FF'
            }, {
                theName: 'crimson',
                theType: 'color',
                theId: '#DC143C'
            }, {
                theName: 'sky blue',
                theType: 'color',
                theId: '#87CEEB'
            }, {
                theName: 'old lace',
                theType: 'color',
                theId: '#FDF5E6'
            }, {
                theName: 'moccasin',
                theType: 'color',
                theId: '#FFE4B5'
            }, {
                theName: 'lavender',
                theType: 'color',
                theId: '#E6E6FA'
            }, {
                theName: 'hot pink',
                theType: 'color',
                theId: '#FF69B4'
            }, {
                theName: 'honeydew',
                theType: 'color',
                theId: '#F0FFF0'
            }, {
                theName: 'dim gray',
                theType: 'color',
                theId: '#696969'
            }, {
                theName: 'dark red',
                theType: 'color',
                theId: '#8B0000'
            }, {
                theName: 'turquoise',
                theType: 'color',
                theId: '#40E0D0'
            }, {
                theName: 'sea shell',
                theType: 'color',
                theId: '#FFF5EE'
            }, {
                theName: 'sea green',
                theType: 'color',
                theId: '#2E8B57'
            }, {
                theName: 'gainsboro',
                theType: 'color',
                theId: '#DCDCDC'
            }, {
                theName: 'deep pink',
                theType: 'color',
                theId: '#FF1493'
            }, {
                theName: 'dark gray',
                theType: 'color',
                theId: '#A9A9A9'
            }, {
                theName: 'dark cyan',
                theType: 'color',
                theId: '#008B8B'
            }, {
                theName: 'dark blue',
                theType: 'color',
                theId: '#00008B'
            }, {
                theName: 'corn silk',
                theType: 'color',
                theId: '#FFF8DC'
            }, {
                theName: 'chocolate',
                theType: 'color',
                theId: '#D2691E'
            }, {
                theName: 'warm white',
                theType: 'color',
                theId: '#DAF17E'
            }, {
                theName: 'steel blue',
                theType: 'color',
                theId: '#4682B4'
            }, {
                theName: 'soft white',
                theType: 'color',
                theId: '#B6DA7C'
            }, {
                theName: 'slate gray',
                theType: 'color',
                theId: '#708090'
            }, {
                theName: 'slate blue',
                theType: 'color',
                theId: '#6A5ACD'
            }, {
                theName: 'royal blue',
                theType: 'color',
                theId: '#4169E1'
            }, {
                theName: 'rosy brown',
                theType: 'color',
                theId: '#BC8F8F'
            }, {
                theName: 'peach puff',
                theType: 'color',
                theId: '#FFDAB9'
            }, {
                theName: 'pale green',
                theType: 'color',
                theId: '#98FB98'
            }, {
                theName: 'orange red',
                theType: 'color',
                theId: '#FF4500'
            }, {
                theName: 'olive drab',
                theType: 'color',
                theId: '#6B8E23'
            }, {
                theName: 'misty rose',
                theType: 'color',
                theId: '#FFE4E1'
            }, {
                theName: 'mint cream',
                theType: 'color',
                theId: '#F5FFFA'
            }, {
                theName: 'lime green',
                theType: 'color',
                theId: '#32CD32'
            }, {
                theName: 'light pink',
                theType: 'color',
                theId: '#FFB6C1'
            }, {
                theName: 'light gray',
                theType: 'color',
                theId: '#D3D3D3'
            }, {
                theName: 'light cyan',
                theType: 'color',
                theId: '#E0FFFF'
            }, {
                theName: 'light blue',
                theType: 'color',
                theId: '#ADD8E6'
            }, {
                theName: 'lawn green',
                theType: 'color',
                theId: '#7CFC00'
            }, {
                theName: 'indian red',
                theType: 'color',
                theId: '#CD5C5C'
            }, {
                theName: 'golden rod',
                theType: 'color',
                theId: '#DAA520'
            }, {
                theName: 'fire brick',
                theType: 'color',
                theId: '#B22222'
            }, {
                theName: 'dark khaki',
                theType: 'color',
                theId: '#BDB76B'
            }, {
                theName: 'dark green',
                theType: 'color',
                theId: '#006400'
            }, {
                theName: 'cool white',
                theType: 'color',
                theId: '#F3F6F7'
            }, {
                theName: 'chartreuse',
                theType: 'color',
                theId: '#7FFF00'
            }, {
                theName: 'cadet blue',
                theType: 'color',
                theId: '#5F9EA0'
            }, {
                theName: 'burly wood',
                theType: 'color',
                theId: '#DEB887'
            }, {
                theName: 'aquamarine',
                theType: 'color',
                theId: '#7FFFD4'
            }, {
                theName: 'alice blue',
                theType: 'color',
                theId: '#F0F8FF'
            }, {
                theName: 'white smoke',
                theType: 'color',
                theId: '#F5F5F5'
            }, {
                theName: 'sandy brown',
                theType: 'color',
                theId: '#F4A460'
            }, {
                theName: 'powder blue',
                theType: 'color',
                theId: '#B0E0E6'
            }, {
                theName: 'papaya whip',
                theType: 'color',
                theId: '#FFEFD5'
            }, {
                theName: 'medium blue',
                theType: 'color',
                theId: '#0000CD'
            }, {
                theName: 'light green',
                theType: 'color',
                theId: '#90EE90'
            }, {
                theName: 'light coral',
                theType: 'color',
                theId: '#F08080'
            }, {
                theName: 'ghost white',
                theType: 'color',
                theId: '#F8F8FF'
            }, {
                theName: 'dodger blue',
                theType: 'color',
                theId: '#1E90FF'
            }, {
                theName: 'dark violet',
                theType: 'color',
                theId: '#9400D3'
            }, {
                theName: 'dark salmon',
                theType: 'color',
                theId: '#E9967A'
            }, {
                theName: 'dark orchid',
                theType: 'color',
                theId: '#9932CC'
            }, {
                theName: 'dark orange',
                theType: 'color',
                theId: '#FF8C00'
            }, {
                theName: 'blue violet',
                theType: 'color',
                theId: '#8A2BE2'
            }, {
                theName: 'yellow green',
                theType: 'color',
                theId: '#9ACD32'
            }, {
                theName: 'spring green',
                theType: 'color',
                theId: '#00FF7F'
            }, {
                theName: 'saddle brown',
                theType: 'color',
                theId: '#8B4513'
            }, {
                theName: 'navajo white',
                theType: 'color',
                theId: '#FFDEAD'
            }, {
                theName: 'light yellow',
                theType: 'color',
                theId: '#FFFFE0'
            }, {
                theName: 'light salmon',
                theType: 'color',
                theId: '#FFA07A'
            }, {
                theName: 'green yellow',
                theType: 'color',
                theId: '#ADFF2F'
            }, {
                theName: 'forest green',
                theType: 'color',
                theId: '#228B22'
            }, {
                theName: 'floral white',
                theType: 'color',
                theId: '#FFFAF0'
            }, {
                theName: 'dark magenta',
                theType: 'color',
                theId: '#8B008B'
            }, {
                theName: 'midnight blue',
                theType: 'color',
                theId: '#191970'
            }, {
                theName: 'medium purple',
                theType: 'color',
                theId: '#9370DB'
            }, {
                theName: 'medium orchid',
                theType: 'color',
                theId: '#BA55D3'
            }, {
                theName: 'lemon chiffon',
                theType: 'color',
                theId: '#FFFACD'
            }, {
                theName: 'deep sky blue',
                theType: 'color',
                theId: '#00BFFF'
            }, {
                theName: 'antique white',
                theType: 'color',
                theId: '#FAEBD7'
            }, {
                theName: 'paleviolet red',
                theType: 'color',
                theId: '#DB7093'
            }, {
                theName: 'pale turquoise',
                theType: 'color',
                theId: '#AFEEEE'
            }, {
                theName: 'light sky blue',
                theType: 'color',
                theId: '#87CEFA'
            }, {
                theName: 'lavender blush',
                theType: 'color',
                theId: '#FFF0F5'
            }, {
                theName: 'daylight white',
                theType: 'color',
                theId: '#CEF4FD'
            }, {
                theName: 'dark turquoise',
                theType: 'color',
                theId: '#00CED1'
            }, {
                theName: 'dark sea green',
                theType: 'color',
                theId: '#8FBC8F'
            }, {
                theName: 'pale golden rod',
                theType: 'color',
                theId: '#EEE8AA'
            }, {
                theName: 'light sea green',
                theType: 'color',
                theId: '#20B2AA'
            }, {
                theName: 'dark slate gray',
                theType: 'color',
                theId: '#2F4F4F'
            }, {
                theName: 'dark slate blue',
                theType: 'color',
                theId: '#483D8B'
            }, {
                theName: 'dark golden rod',
                theType: 'color',
                theId: '#B8860B'
            }, {
                theName: 'blanched almond',
                theType: 'color',
                theId: '#FFEBCD'
            }, {
                theName: 'medium turquoise',
                theType: 'color',
                theId: '#48D1CC'
            }, {
                theName: 'medium sea green',
                theType: 'color',
                theId: '#3CB371'
            }, {
                theName: 'light steel blue',
                theType: 'color',
                theId: '#B0C4DE'
            }, {
                theName: 'light slate gray',
                theType: 'color',
                theId: '#778899'
            }, {
                theName: 'dark olive green',
                theType: 'color',
                theId: '#556B2F'
            }, {
                theName: 'corn flower blue',
                theType: 'color',
                theId: '#6495ED'
            }, {
                theName: 'medium violet red',
                theType: 'color',
                theId: '#C71585'
            }, {
                theName: 'medium slate blue',
                theType: 'color',
                theId: '#7B68EE'
            }, {
                theName: 'medium aquamarine',
                theType: 'color',
                theId: '#66CDAA'
            }, {
                theName: 'medium spring green',
                theType: 'color',
                theId: '#00FA9A'
            }, {
                theName: 'light golden rod yellow',
                theType: 'color',
                theId: '#FAFAD2'
            }
        ];
    }
    getParserItems() {
        return [
            {
                theName: 'is',
                theType: 'status'
            },
            {
                theName: 'do',
                theType: 'status'
            },
            {
                theName: 'who',
                theType: 'status'
            },
            {
                theName: 'how',
                theType: 'status'
            },
            {
                theName: 'has',
                theType: 'status'
            },
            {
                theName: 'get',
                theType: 'status'
            },
            {
                theName: 'did',
                theType: 'status'
            },
            {
                theName: 'day',
                theType: 'delay'
            },
            {
                theName: 'are',
                theType: 'status'
            },
            {
                theName: 'all',
                theType: 'all'
            },
            {
                theName: 'whos',
                theType: 'status'
            },
            {
                theName: 'whom',
                theType: 'status'
            },
            {
                theName: 'when',
                theType: 'status'
            },
            {
                theName: 'what',
                theType: 'status'
            },
            {
                theName: 'were',
                theType: 'status'
            },
            {
                theName: 'week',
                theType: 'delay'
            },
            {
                theName: 'hows',
                theType: 'status'
            },
            {
                theName: 'hour',
                theType: 'delay'
            },
            {
                theName: 'have',
                theType: 'status'
            },
            {
                theName: 'give',
                theType: 'status'
            },
            {
                theName: 'gets',
                theType: 'status'
            },
            {
                theName: 'does',
                theType: 'status'
            },
            {
                theName: 'days',
                theType: 'delay'
            },
            {
                theName: 'which',
                theType: 'status'
            },
            {
                theName: 'where',
                theType: 'status'
            },
            {
                theName: 'whens',
                theType: 'status'
            },
            {
                theName: 'whats',
                theType: 'status'
            },
            {
                theName: 'weeks',
                theType: 'delay'
            },
            {
                theName: 'level',
                theType: 'level'
            },
            {
                theName: 'hours',
                theType: 'delay'
            },
            {
                theName: 'gives',
                theType: 'status'
            },
            {
                theName: 'every',
                theType: 'all'
            },
            {
                theName: 'armed',
                theType: 'alarm'
            },
            {
                theName: 'wheres',
                theType: 'status'
            },
            {
                theName: 'status',
                theType: 'status'
            },
            {
                theName: 'second',
                theType: 'delay'
            },
            {
                theName: 'minute',
                theType: 'delay'
            },
            {
                theName: 'levels',
                theType: 'level'
            },
            {
                theName: 'disarm',
                theType: 'alarm'
            },
            {
                theName: 'degree',
                theType: 'level'
            },
            {
                theName: 'degrees',
                theType: 'level'
            },
            {
                theName: 'seconds',
                theType: 'delay'
            },
            {
                theName: 'percent',
                theType: 'level'
            },
            {
                theName: 'minutes',
                theType: 'delay'
            },
            {
                theName: 'percents',
                theType: 'level'
            },
            {
                theName: 'brightness',
                theType: 'level'
            },
            {
                theName: 'everything',
                theType: 'all'
            },
            {
                theName: 'armed stay',
                theType: 'alarm'
            },
            {
                theName: 'armed away',
                theType: 'alarm'
            },
            {
                theName: 'illuminate',
                theType: 'level'
            },
            {
                theName: 'percentages',
                theType: 'level'
            },
            {
                theName: 'millisecond',
                theType: 'delay'
            },
            {
                theName: 'illumination',
                theType: 'level'
            },
            {
                theName: 'milliseconds',
                theType: 'delay'
            }
        ];
    }
    boolValues() {
        return ['enable', 'disable'];
    }
    feedbackValues() {
        return ['default', 'disable', 'short'];
    }
    settingItems() {
        return {
            'allow personality': this.boolValues(),
            'quiet mode': this.boolValues(),
            'test mode': this.boolValues(),
            'followup mode': this.boolValues(),
            'send debug data': this.boolValues(),
            'feedback type': this.feedbackValues()
        };
    }
    helpItemsDesc() {
        return ['list routines', 'list modes', 'devices in room', 'list rooms', 'shortcuts in room', 'example commands', 'update settings or update configuration'];
    }
    helpItems() {
        return ['routines', 'modes', 'rooms', 'example'];
    }
}
module.exports = ESUtils;