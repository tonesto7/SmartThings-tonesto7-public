'use strict';
class Settings {
    constructor(esClass) {
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.imgPathUrl = esClass.imgPathUrl;
        this.attributes = esClass.alexaHandler.attributes;
        this.allowPersonality = esClass.allowPersonality;
        this.followupMode = esClass.followupMode;
        this.esData = esClass.esData;
        this.response = esClass.alexaHandler.response;
        this.alexaHandler = esClass.alexaHandler;
        this.emit = esClass.alexaHandler.emit;
        this.event = esClass.alexaHandler.event;
        this.hereData = esClass.hereData;
        this.respMap = esClass.respStrings;
        this.utils = esClass.utils;
        this.devId = esClass.alexaHandler.handler.theId;
        this.stHost = esClass.stHost;
        this.stPort = esClass.stPort;
        this.stPath = esClass.stPath;
        this.stAppID = esClass.stAppID;
        this.skillName = 'EchoSistant Evolution Settings';
        this.echoHasDisplay = esClass.echoHasDisplay;
        this.settingItems = esClass.utils.settingItems();
    }

    handleSettings(setTypeOpts = undefined) {
        console.log('handleSettings| setModeStage: ' + this.attributes.setModeStage + ' | setTypeOpts: ' + setTypeOpts);
        var ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        var settingNames = Object.keys(this.settingItems).map(theKey => theKey);
        var setNames = settingNames;
        var setOptions = this.attributes.setTypeOpts;
        if (ttstext !== undefined) {
            console.log('handleSettings | ttstext: ' + ttstext);
        }
        if (ttstext === undefined && setTypeOpts === undefined && this.attributes.setModeStage === 'needSetType') {
            this.attributes.setModeStage = 'needSetName';
        }
        if (this.attributes.setModeStage === 'needSetType') {
            console.log('needSetType');
            if (ttstext === undefined) {
                this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Type).toString() + setOptions.sort().join(', or');
                this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Type_Reprompts).toString() + setOptions.sort().join(', or');
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                if (this.echoHasDisplay === true) {
                    const template = this.utils.generateShowCard({
                        skillName: 'Available Options',
                        listItems: this.utils.showListItemsBuilder(setOptions, 'setOptsItem'),
                        token: 'setOptsList',
                        type: 'list1'
                    });
                    this.response.renderTemplate(template);
                }
                return this.emit(':responseReady');
            } else {
                let typeMatch = false;
                if (ttstext.match('\\b' + 'app preferences' + '\\b')) {
                    console.log('app preferences matched');
                    typeMatch = true;
                    this.attributes.setModeStage = 'needSetName';
                    this.attributes.speechOutput = 'Available settings are ' + settingNames.sort().join(', ');
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Name).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Available Settings',
                            listItems: this.utils.showSettingItemsBuilder(this.settingItems, this.esData.settings, 'setNamesItem'),
                            token: 'setNamesList',
                            type: 'list1'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                } else if (ttstext.match('\\b' + 'echo devices' + '\\b')) {
                    console.log('echo devices matched');
                    typeMatch = true;
                    this.attributes.setModeStage = 'needDevPrefs';
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Type_Options).toString();
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Type_Options).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Reset Here Association',
                            priText: this.attributes.speechOutput
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                }
                if (typeMatch === false) {
                    console.log('!!!needSetType NOT matched!!! | setOptions: ' + setOptions);
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Type_Missed_List).toString() + setOptions.sort().join(', or');
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Type_Reprompts_List).toString() + setOptions.sort().join(', or');
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Option Not Understood',
                            listItems: this.utils.showListItemsBuilder(setOptions, 'setOptsItem'),
                            token: 'setOptsList',
                            type: 'list1'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                }
            }
        }
        if (this.attributes.setModeStage === 'needDevPrefs') {
            console.log('needDevPrefs');
            if (ttstext === undefined) {
                this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Type_Options).toString();
                this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Type_Options).toString();
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                if (this.echoHasDisplay === true) {
                    const template = this.utils.generateShowCard({
                        skillName: 'Select a Device Option',
                        // priText: this.attributes.speechOutput
                        listItems: this.utils.showListItemsBuilder(['reset'], 'devPrefItem'),
                        token: 'devPrefList',
                        type: 'list1'
                    });
                    this.response.renderTemplate(template);
                }
                return this.emit(':responseReady');
            } else {
                let prefMatch = false;
                if (ttstext.match('\\b' + 'reset' + '\\b')) {
                    console.log('here room reset matched');
                    prefMatch = true;
                    this.attributes.setModeStage = undefined;
                    let hDevId = this.attributes.hereDevId || undefined;
                    if ((hDevId !== undefined && this.hereData.echoDevices !== undefined) || this.hereData.echoDevices[hDevId] !== undefined || this.hereData.echoDevices[hDevId]['room'] !== undefined) {
                        delete this.hereData.echoDevices[hDevId]['room'];
                        if (this.hereData.echoDevices[hDevId]['room'] === undefined) {
                            console.log('echo devices room cleared successfully!');
                            // this.attributes.setModeStage = "devResetHere";
                            if (this.followupMode === false) {
                                this.attributes.speechOutput = 'I have successfully cleared the room association with this Echo Device.';
                                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput));
                                if (this.echoHasDisplay === true) {
                                    const template = this.utils.generateShowCard({
                                        skillName: this.skillName,
                                        priText: this.attributes.speechOutput
                                    });
                                    this.response.renderTemplate(template);
                                }
                                return this.emit(':responseReady');
                            } else {
                                console.log('followupMode On: ', this.attributes.speechOutput);
                                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.utils.getSpeechItem(this.respMap.Followup, 'Default', this.allowPersonality)));
                                return this.emit(':responseReady');
                            }
                        } else {
                            console.log('echo device room wasnt cleared because of a problem');
                            this.attributes.speechOutput = 'I had a problem removing the room association with this Echo Device.';
                            this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput));
                            if (this.echoHasDisplay === true) {
                                const template = this.utils.generateShowCard({
                                    skillName: this.skillName,
                                    priText: this.attributes.speechOutput,
                                    type: 'body2',
                                    sideImage: this.imgPathUrl + 'issue.png'
                                });
                                this.response.renderTemplate(template);
                            }
                            return this.emit(':responseReady');
                        }
                    } else {
                        console.log('!!!needDevPref NOT matched!!!');
                        this.attributes.speechOutput = 'I was unable to find any room association to remove for this echo device.';
                        this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput));
                        if (this.echoHasDisplay === true) {
                            const template = this.utils.generateShowCard({
                                skillName: this.skillName,
                                priText: this.attributes.speechOutput
                            });
                            this.response.renderTemplate(template);
                        }
                        return this.emit(':responseReady');
                    }
                }
                if (prefMatch === false) {
                    console.log('!!!needDevPref NOT GIVEN!!!');
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Type_Options_Missed).toString();
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Type_Options).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Device Preference Option Not Received',
                            // priText: this.attributes.speechOutput
                            listItems: this.utils.showListItemsBuilder(['reset'], 'devPrefItem'),
                            token: 'devPrefList',
                            type: 'list1'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                }
            }
        }
        if (this.attributes.setModeStage === 'needSetName') {
            console.log('needSetName');
            if (ttstext === undefined || this.utils.cleanString(ttstext).match('\\blist\\b')) {
                this.attributes.speechOutput = 'Available settings are ' + settingNames.sort().join(', ');
                this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Name).toString();
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                if (this.echoHasDisplay === true) {
                    const template = this.utils.generateShowCard({
                            skillName: 'Available Settings',
                            listItems: this.utils.showSettingItemsBuilder(this.settingItems, this.esData.settings, 'setNamesItem'),
                            token: 'setNamesList',
                            type: 'list1'
                        },
                        'settings_needSetName_section'
                    );
                    this.response.renderTemplate(template);
                }
                return this.emit(':responseReady');
            } else {
                let nameMatch = false;
                let setMatch;
                setNames.forEach(setting => {
                    if (ttstext.match('\\b' + setting + '\\b')) {
                        console.log('SetName MATCHED:' + setting);
                        setMatch = setting;
                        nameMatch = true;
                    }
                });
                if (nameMatch === true && setMatch !== undefined) {
                    this.attributes.setModeStage = 'needSetValue';
                    this.attributes.setModeSetting = setMatch;
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Values).toString() + this.settingItems[setMatch].join(', ');
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Values_Reprompts).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Accepted Values',
                            listItems: this.utils.showListItemsBuilder(this.settingItems[setMatch], 'setValsItems'),
                            token: 'setValsList',
                            type: 'list1'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                } else {
                    console.log('needSetName');
                    this.attributes.speechOutput = 'Available settings are ' + settingNames.sort().join(', ');
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Name_Missed).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: 'Still Need a Setting Name',
                            priText: this.attributes.speechOutput
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                }
            }
        }
        if (this.attributes.setModeStage === 'needSetValue') {
            let valueMatch = false;
            let valMatched;
            if (ttstext !== undefined && this.attributes.setModeSetting) {
                this.settingItems[this.attributes.setModeSetting].forEach(value => {
                    if (ttstext.match('\\b' + value + '\\b')) {
                        console.log('SetValue MATCHED:' + value);
                        valueMatch = true;
                        valMatched = value;
                    }
                });
                if (valueMatch === true && valMatched !== undefined) {
                    let settingKey = this.utils.camelize(this.attributes.setModeSetting);
                    let setObj = this.esData.settings || {};
                    let newValue;
                    switch (valMatched) {
                        case 'enable':
                            newValue = true;
                            break;
                        case 'disable':
                            newValue = false;
                            break;
                        default:
                            newValue = valMatched;
                            break;
                    }
                    setObj[settingKey] = newValue;
                    this.esData.settings = setObj;
                    this.updateEsSetting(settingKey, newValue);
                } else {
                    console.log('SetValue NOT MATCHED:');
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Values_Missed).toString();
                    this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Values_Missed).toString();
                    this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                    if (this.echoHasDisplay === true) {
                        let template = this.utils.generateShowCard({
                            skillName: 'Usable Value Not Received',
                            priText: this.attributes.speechOutput
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                }
            } else {
                console.log('SetValue NOT GIVEN!!!');
                this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Values).toString() + this.settingItems[this.attributes.setModeSetting].join(',or ');
                this.attributes.repromptSpeech = this.utils.getRandomItem(this.respMap.Settings.Values_Reprompts).toString();
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
                if (this.echoHasDisplay === true) {
                    const template = this.utils.generateShowCard({
                        skillName: 'Please Select a Value',
                        listItems: this.utils.showListItemsBuilder(this.settingItems[this.attributes.setModeSetting], 'setValsItems'),
                        token: 'setValsList',
                        type: 'list1'
                    });
                    this.response.renderTemplate(template);
                }
                return this.emit(':responseReady');
            }
        }
    }

    updateEsSetting(keyName, keyValue) {
        // logTime('updateEsSetting');
        console.log('updateEsSetting');
        if (this.esData.settings[keyName] !== keyValue) {
            console.error('ESLogging| Error during DynamoDB setting update: ' + this.results.response.error);
            this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Problem);
            this.response.speak(this.attributes.speechOutput);
            return this.emit('responseReady');
        } else {
            const processData = JSON.stringify({
                cmdTypes: {
                    appCmds: ['settingUpdate']
                },
                theDelay: 0,
                theCommand: 'settingUpdate',
                setValues: this.esData.settings,
                lambdaInfo: {
                    version: this.appVersion,
                    versionDt: this.appVerDate
                }
            });

            const options = {
                port: this.stPort,
                host: this.stHost,
                path: this.stPath,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(processData, 'utf8')
                }
            };

            this.utils
                .httpRequest(options, processData)
                .then(resp => {
                    // logTime('Response from ST Setting Update ' + resp);
                    console.log('Response from ST Setting Update ' + resp);
                    this.attributes.speechOutput = this.utils.getRandomItem(["ok i've set " + this.attributes.setModeSetting + ' to ' + keyValue, 'ok ' + this.attributes.setModeSetting + ' is now set to ' + keyValue]);
                    console.log('settings update ST OK Alexa Resp: ' + this.attributes.speechOutput);
                    this.attributes.setModeStage = undefined;
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: this.skillName,
                            priText: '<b>' + this.utils.camelize(this.attributes.setModeSetting) + '</b>: is (<u>' + keyValue + '</u>)'
                        });
                        this.response.renderTemplate(template);
                    }
                    if (this.followupMode === false) {
                        console.log('followupMode Off: ', this.attributes.speechOutput);
                        this.response.speak(this.attributes.speechOutput);
                        return this.emit(':responseReady');
                    } else {
                        console.log('followupMode On: ', this.attributes.speechOutput);
                        this.response.speak(this.attributes.speechOutput).listen(this.utils.getSpeechItem(this.respMap.Followup, 'Default', this.allowPersonality));
                        return this.emit(':responseReady');
                    }
                })
                .catch(err => {
                    console.error('ESLogging| Error Sending Setting Update to ST: ' + err);
                    this.attributes.speechOutput = this.utils.getRandomItem(this.respMap.Settings.Problem);
                    this.response.speak(this.attributes.speechOutput);
                    if (this.echoHasDisplay === true) {
                        const template = this.utils.generateShowCard({
                            skillName: this.skillName,
                            priText: this.attributes.speechOutput,
                            type: 'body2',
                            sideImage: this.imgPathUrl + 'issue.png'
                        });
                        this.response.renderTemplate(template);
                    }
                    return this.emit(':responseReady');
                });
        }
    }
}
module.exports = Settings;