'use strict';
class Here {
    constructor(esClass) {
        this.attributes = esClass.alexaHandler.attributes;
        this.response = esClass.alexaHandler.response;
        this.alexaHandler = esClass.alexaHandler;
        this.emit = esClass.alexaHandler.emit;
        this.event = esClass.alexaHandler.event;
        this.imgPathUrl = esClass.imgPathUrl;
        this.respStrings = esClass.respStrings;
        this.devId = esClass.alexaHandler.handler.theId;
        this.utils = esClass.utils;
        this.skillName = 'EchoSistant Evolution - Here';
        this.echoHasDisplay = esClass.echoHasDisplay;
    }
    compareWords(str1, str2) {
        if (str1.match('\\b' + str2 + '\\b')) {
            return true;
        }
        if (this.utils.string_similarity(str1, str2) > .5) {
            return true;
        }
        return false;
    }
    handleHere() {
        console.log('handleHere deviceId: ', this.devId);
        if (this.devId.startsWith('amzn1.ask.device')) {
            console.log(this.event.request.intent.slots.ttstext.value);
            // console.log('usingHere', this.attributes.usingHere);
            if (this.attributes.usingHere === 'FirstCall') {
                this.attributes.usingHere = 'ListRooms';
                this.attributes.commandBeforeHere = this.event.request.intent.slots.ttstext.value;
                this.attributes.speechOutput = this.utils.getRandomItem(this.respStrings.Here.Default);
                this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.speechOutput));
                if (this.echoHasDisplay === true) {
                    const template = this.utils.generateShowCard({
                        skillName: this.skillName,
                        priText: this.attributes.speechOutput
                    });
                    this.response.renderTemplate(template);
                }
                return this.emit(':responseReady');
            } else {
                if (this.attributes.usingHere === 'ListRooms') {
                    const allRoomNames = this.alexaHandler.esData.locData.availableRooms.map(room => this.utils.cleanString(room.name));
                    const ttsValue = this.utils.cleanString(this.event.request.intent.slots.ttstext.value);
                    if (this.compareWords(ttsValue, 'list')) {
                        this.attributes.speechOutput = this.utils.getRandomItem(this.respStrings.Here.PreList) + allRoomNames.sort().join(', <break time="500ms"/>');
                        this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.speechOutput));
                        if (this.echoHasDisplay === true) {
                            const template = this.utils.generateShowCard({
                                skillName: 'Room List',
                                listItems: this.utils.showListItemsBuilder(allRoomNames.sort(), 'hereRoomItem'),
                                token: 'hereRoomList',
                                type: 'list1'
                            });
                            this.response.renderTemplate(template);
                        }
                        return this.emit(':responseReady');
                    } else {
                        const theMatch = ttsValue.match('\\b' + allRoomNames.join('\\b|\\b') + '\\b');
                        if (theMatch !== null) {
                            this.attributes.usingHere = undefined;
                            let roomObj = this.alexaHandler.hereData || {};
                            if (roomObj.echoDevices === undefined) {
                                roomObj['echoDevices'] = {};
                            }
                            roomObj.echoDevices[this.devId] = { room: theMatch[0] };
                            this.alexaHandler.hereData = roomObj;
                        } else {
                            for (const room of allRoomNames.sort()) {
                                if (this.utils.string_similarity(ttsValue.replace('room', '').trim(), room.replace('room', '').trim()) > .2) {
                                    this.attributes.usingHere = undefined;
                                    let roomObj = this.alexaHandler.hereData || {};
                                    if (roomObj.echoDevices === undefined) {
                                        roomObj['echoDevices'] = {};
                                    }
                                    roomObj.echoDevices[this.devId] = { room: room };
                                    this.alexaHandler.hereData = roomObj;
                                    break;
                                }
                            }
                        }
                        if (this.alexaHandler.hereData.echoDevices === undefined || this.alexaHandler.hereData.echoDevices[this.devId] === undefined || this.alexaHandler.hereData.echoDevices[this.devId]['room'] === undefined) {
                            this.attributes.speechOutput = this.utils.getRandomItem(this.respStrings.Here.Problem) + allRoomNames.sort().join(', <break time="500ms"/>');
                            this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.utils.getRandomItem(this.respStrings.Here.PreList) + allRoomNames.sort().join(', <break time="500ms"/>')));
                            if (this.echoHasDisplay === true) {
                                const template = this.utils.generateShowCard({
                                    skillName: this.skillName,
                                    listItems: this.utils.showListItemsBuilder(allRoomNames.sort(), 'hereRoomList'),
                                    token: 'hereRoomList',
                                    type: 'list1'
                                });
                                this.response.renderTemplate(template);
                            }
                            return this.emit(':responseReady');
                        } else {
                            this.attributes.usingHere = undefined;
                            this.attributes.speechOutput = this.utils.getRandomItem(this.respStrings.Here.Success) + this.alexaHandler.hereData.echoDevices[this.devId]['room'] + '. ' + this.utils.getRandomItem(this.respStrings.Here.ResumePrevCmd) + this.attributes.commandBeforeHere + '?';
                            this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.utils.getRandomItem(this.respStrings.Here.ResumePrevCmd) + this.alexaHandler.attributes.commandBeforeHere));
                            if (this.echoHasDisplay === true) {
                                const template = this.utils.generateShowCard({
                                    skillName: this.skillName,
                                    priText: this.attributes.speechOutput
                                });
                                this.response.renderTemplate(template);
                            }
                            return this.emit(':responseReady');
                        }
                    }
                } else {
                    this.attributes.usingHere = undefined;
                    return this.emit('Unhandled');
                }
            }
        } else {
            this.attributes.usingHere = undefined;
            this.attributes.speechOutput = this.utils.getRandomItem(this.respStrings.Here.NotFound);
            if (this.echoHasDisplay === true) {
                const template = this.utils.generateShowCard({
                    skillName: this.skillName,
                    priText: this.attributes.speechOutput,
                    type: 'body2',
                    sideImage: this.imgPathUrl + 'issue.png'
                });
                this.response.renderTemplate(template);
            }
            return this.emit('SessionEndedRequest');
        }
    }
}

module.exports = Here;