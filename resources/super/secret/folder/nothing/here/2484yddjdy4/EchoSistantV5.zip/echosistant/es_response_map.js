class Responses {
    constructor(esClass) {
        this.esData = esClass.esData;
        this.utils = esClass.utils;
    }
    todDesc(prefix = true) {
        const tod = this.esData.locData.todDesc;
        return tod === 'Day' ? (prefix ? 'Today' : tod) : (prefix ? 'this ' : ' ') + tod;
    }
    staticResponses() {
        return {
            Welcome: {
                Default: ['Welcome to the Echosistant Evolution Skill. Please give me a command.', 'Welcome to EchoSistant, What can I help you with today?', 'Hello, what can Echosistant help you with today?', 'Hi, What can I do to make your life easier?'],
                Default_Attitude: ["Yep! It's me your wonderful amazing echosistant!", 'What do you need now?', 'What do you want?, ' + this.todDesc(true) + ' sure is a great time for you to leave me alone!.', 'What do you want from me?'],
                Reprompts: ['I need a command before I can be of any help. What can I help you with?, If you are not sure then say "help"', 'All I need is a command to proceed., If you are not sure then say "help"', 'You can say help to hear a list of options available.'],
                Reprompts_Attitude: ["Give me something to do because I'm getting impatient!, if you can't figure out what to say then ask for 'help'", "Please don't waste my time, I need a command!, or just ask me for some help already!"]
            },
            Help: {
                Default: [
                    'You can say things like turn off the lights in the basement, or set the mode to evening, or run good night.',
                    "You can configure a specific device for a room, start by saying <emphasis level='strong'>setup my echo in here</emphasis>, you will be asked set a room. Once a room is set just use <emphasis level='strong'>in here</emphasis> to control devices in that room only.",
                    "You can add multiple commands to a single request by adding an <emphasis level='strong'> and </emphasis> between them.  An example is 'Turn off the dining room lights and turn on the living room'"
                ],
                Default_Attitude: [],
                Reprompts: ['Need more Help?', 'What were you looking to do?', 'How can I help you?'],
                Reprompts_Attitude: ['What else can you bother me with?', 'What else were you looking to do?', 'Are you finished wasting my time or do you need something else?'],
                Type: ["What can I help you with?,  If you are not sure, say 'I don't know', ", "How can I help you?,  If you are not sure, say 'I don't know',"],
                Type_Attitude: [
                    "Tell me what you want to know!,  If you are not sure, say 'I don't know', ",
                    'Yes! Let me hurry up and answer your questions, ',
                    "I don't really feel like being helpful " + this.todDesc() + ", What do you need?, If you are not sure, just say 'I don't know', ",
                    "I'm not really in a helpful mood " + this.todDesc() + ', but go ahead and ask me something anyway! ',
                    "I haven't really been feeling very helpful " + this.todDesc() + ", but I will try and help you anyways. If you are not sure what to ask, just say 'I don't know', otherwise tell me what you need! ",
                    "I'm not really in a helpful mood " + this.todDesc() + ', but go ahead and ask me something anyway! '
                ],
                Type_List: ['You can ask me things like, ', 'I can help you with the following, '],
                Type_List_Attitude: ['here are the boring things you can say, ', "I don't really feel like being helpful " + this.todDesc() + ', but I guess you can ask the following, '],
                Type_Reprompts: ["Ok, You didn't give me a item. What help can I give you?", "I'm going to need a item before i can provide you with help!", 'What question can i answer for you? ', 'let me know what you would like help with!. '],
                Type_Reprompts_Attitude: ["Give me something to do because I'm getting impatient!", "Please don't waste my time, I need to know what you need help with!"],
                Type_Missed: ["I'm sorry I didn't understand the item given,  Which help item are you looking for?", 'I seem to be having some issues hearing today, What is the item name again? ', "I wasn't able to understand the option given, Please try again! ", "I could not hear the response given, Let's try again! "],
                Type_Missed_Attitude: ["ugh! You don't seem to be speaking very clearly!, Tell me again what you are looking for?", 'nope!, It sounds like you have marbles in your mouth, Try again! ', 'Are you talking with food in your mouth again?  Give it another try! '],
                Room: ['Which room should we use? ', 'Which room?', 'Give me a room to work with! '],
                Room_Attitude: ['I need a room so I can get this over with! ', 'Give me the room so i can go back to being silent again! ', "I'm going to need a room to working with! "],
                Room_Reprompts: ["You didn't give me a room. Please try again! ", 'No room was given! Give it another try!, '],
                Room_Reprompts_Attitude: ["How hard is it to give me a room name? Let's try again! "],
                Room_Reprompts_List: ["You didn't give me a room. Available rooms are ", 'No room was given. The Available rooms are, '],
                Room_Reprompts_List_Attitude: ["How hard is it to give me a room name? Let's try again! The rooms are, "],
                Room_Missed_List: ["I wasn't able to find that room. Available rooms are ", 'No room was given. The Available rooms are '],
                Room_Missed_List_Attitude: [],
                Room_Missed: ["I wasn't able to find that room. Please try again. ", 'No room found that matches the one given. give it another go please! '],
                Room_Missed_Attitude: ['Ugh! I could not find the room name you just mumbled to me.  Say it again!. ', 'Nothing was found to match the stuff you just said to me.  Repeat it again! ']
            },
            Stop: {
                Default: ['I am here if you need me.', 'Hopefully I will talk to you soon.', 'Oh well, maybe we will be more lucky next time.', 'Very well! Have a wonderful ' + this.todDesc(false) + '!', 'No worries. Talk to you soon!.'],
                Default_Attitude: ['Fine I will leave you alone.', 'Suit yourself quitter!.', "<say-as interpret-as='interjection'>Darn</say-as> now I feel sad.", "Alright, <say-as interpret-as='interjection'>good luck, I guess</say-as>.", "<say-as interpret-as='interjection'>ouch</say-as> that hurts."]
            },
            Followup: {
                Default: ['Would you like to do something else?', 'Is there something else I can do for you?', 'Need anything else?', 'What else would you like to do?', 'Did you want to do something else?'],
                Default_Attitude: ['What else can I do to help you waste my time?', "What else do you need? I can't wait around all day!", 'Is there anything else? If you are too confused to remember what to say, try back later.']
            },
            Problem: {
                Default: ['There was an issue with the command. Please try again.', "I didn't understand the command, can you try again?"],
                Default_Attitude: ["<say-as interpret-as='interjection'>ruh roh</sa-as> Something went wrong. Try it again!", "<say-as interpret-as='interjection'>dun dun dun</sa-as> Error detected! Please try again!"],
                Reprompts: ['Would you like to try again?', 'Please contact support or try again.'],
                Reprompts_Attitude: ["Well I guess you can't figure it out either... One more try?", 'I asked you a question. Would you like to answer me?', "This isn't rocket science.  Give me an answer!"]
            },
            Settings: {
                Type: ['What would you like to modify?, your choices are ', 'which setting are we modifying?, your options are '],
                Type_Reprompts: ['Which option are we modifying? ', 'I need a option to proceed! '],
                Type_Reprompts_List: ['Which option are we modifying, Say ', 'I need a option to proceed!. Choose '],
                Type_Missed: ["I wasn't able to understand the option given, Please try again! ", "I couldn't hear the response you gave, Let's try again! "],
                Type_Missed_List: ["I wasn't able to understand the option given, Please Say ", "I couldn't hear the response you gave, Say "],
                Type_Options: ['Would you like to reset this devices room association? Just say Reset!'],
                Type_Options_Missed: ["I wasn't able to understand the response given, Please say Reset Room!", "I couldn't hear the response you gave, Say Reset room to proceed!"],
                Problem: ['There was an issue updating the settings database. Please try your request again later.', 'Something went wrong while updating the settings database. Please check the logs.'],
                Name: ['Which setting are we modifying? To list the available options, say list.', 'Give me a setting name to modify. To list the available options, say list.'],
                Name_Reprompts: ['Which setting will we be modifying?', 'To list the available options, say list.'],
                Name_Missed: ["I didn't understand the setting name given,  Which setting did you want to modify?", 'I seem to be having some hearing problems today, What is the setting name again?'],
                Values: ['The accepted values are ', 'The values available are '],
                Values_Reprompts: ["Ok, You didn't give me a value. What should I make the value?", "I'm going to need a value before i can change anything!"],
                Values_Missed: ["I didn't understand the setting value given,  Can you please repeat the value again?", 'I am definitely having hearing issues today, What was that value again?']
            },
            Here: {
                Default: ["Which room is this device in? If you'd like me to list the available rooms, say list rooms.", 'This Echo device has not been assigned to a room, Which room is this? To list the available rooms, say list rooms.'],
                PreList: ['Available Rooms are ', 'Rooms Available are ', 'Room Options are '],
                Problem: ["I wasn't able to find that room. Available rooms are ", 'No room has been set for this Echo. The Available rooms are '],
                Success: ["You've successfully set the default room for this echo device to ", 'This device is now assigned to '],
                ResumePrevCmd: ['Would you like to ', 'Do you still want to ', 'Should I still '],
                NotFound: ["Please use the <emphasis level='strong'>here</emphasis> command from a physical echo device.", "You have to use a real device when using the <emphasis level='strong'>here</emphasis> command."]
            },
            Parser: {
                Default: ['I will add something meaningful later. '],
                Default_Attitude: ["Yep! It's me your wonderful amazing echosistant!.", 'What do you need now?', 'What do you want?.  Today sure is a great day for you to leave me alone!.', 'What do you want?'],
                Reprompts: ['I really need a valid command before I can anything for you. What can I help you with?', 'All I need is a command to proceed.', 'You can say help to hear a list of options available.'],
                Reprompts_Attitude: ["Give me something to do because I'm getting impatient!", "Please don't waste my time, I need a command!"]
            },
            Status: {
                Not_Found: ["I couldn't find any devices matching the criteria you are asking for!", "I wasn't able to find any devices matching the item you requested!", 'No devices were found to match you request!'],
                Not_Found_Attitude: ["I couldn't find any devices, are you sure you know your own home?"]
            }
        };
    }
}
module.exports = Responses;