'use strict';

class StatusInfo {
    constructor(esClass) {
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.attributes = esClass.alexaHandler.attributes;
        this.allowPersonality = esClass.allowPersonality;
        this.followupMode = esClass.followupMode;
        this.response = esClass.alexaHandler.response;
        this.alexaHandler = esClass.alexaHandler;
        this.emit = esClass.alexaHandler.emit;
        this.event = esClass.alexaHandler.event;
        this.esData = esClass.esData;
        this.hereData = esClass.hereData;
        this.respMap = esClass.respStrings;
        this.utils = esClass.utils;
        this.devId = esClass.alexaHandler.handler.theId;
        this.skillName = 'EchoSistant Evolution Status';
        this.echoHasDisplay = esClass.echoHasDisplay;
        this.settingItems = esClass.utils.settingItems();
    }

    shmAlarmDesc(val) {
        switch (val) {
            case "armedstay":
                return "armed stay";
            case "armedaway":
                return "armed away";
            default:
                return val;
        }
    }

    appStatus() {
        const devData = this.esData.devData;
        const locData = this.esData.locData;

        let speechOutput = '';
        let showOutput = '';

        //Intro
        speechOutput += 'Welcome to EchoSistant Evolution!, ';
        showOutput += '<font size="2"><b><u>Version Info:</u></b><br/>';
        speechOutput += "Lambda version <say-as interpret-as='cardinal'>" + this.appVersion + '</say-as>. ';
        showOutput += 'Lambda: (' + this.appVersion + ')<br/>';
        speechOutput += "Main SmartApp version <say-as interpret-as='cardinal'>" + locData.verInfo.app + '</say-as>. ';
        showOutput += 'Main SmartApp: (' + locData.verInfo.app + ')<br/>';
        speechOutput += "Profile Version <say-as interpret-as='cardinal'>" + locData.verInfo.profile + '</say-as>. ';
        showOutput += 'Profile SmartApp: ' + locData.verInfo.profile + ')<br/>';
        speechOutput += "Shortcuts Version <say-as interpret-as='cardinal'>" + locData.verInfo.shortcuts + '</say-as>. ';
        showOutput += 'Shortcuts SmartApp: (' + locData.verInfo.shortcuts + ')<br/><br/>';
        speechOutput += 'Your SmartThings Location is currently set to, ' + this.utils.cleanString(locData.curStMode) + ' mode. ';
        speechOutput += locData.shm_state !== undefined ? 'The alarm is currently, ' + this.shmAlarmDesc(this.utils.cleanString(locData.shm_state)) + '. ' : "";

        speechOutput += "Let's Move on to the Database, ";
        showOutput += '<b><u>Database Items:</u></b><br/>';

        //devices
        const devices = [];
        devData.map(obj => devices.push(obj.label));
        speechOutput += 'There are ' + devices.length + ' devices,';
        showOutput += 'Devices: (' + devices.length + ')<br/>';

        //roomNames
        const allRoomNames = this.esData.locData.availableRooms.map(room => room.name);
        speechOutput += allRoomNames.length + ' rooms, ';
        showOutput += 'Rooms: (' + allRoomNames.length + ')<br/>';
        //modes
        const modes = [];
        locData.availStModes.map(obj => modes.push(obj.name));
        speechOutput += modes.length + ' modes, ';
        showOutput += 'Modes: (' + modes.length + ')<br/>';
        //routines
        const routines = [];
        locData.availStRoutines.map(obj => routines.push(obj.name));
        speechOutput += routines.length + ' routines available in the database,';
        showOutput += 'Routines: (' + routines.length + ')<br/><br/>';

        speechOutput += "Now we'll move on to settings, ";
        showOutput += '<b><u>Settings:</u></b><br/>';

        const settingNames = Object.keys(this.settingItems).map(theKey => theKey);
        const setNames = settingNames;
        setNames.sort().forEach(setting => {
            speechOutput += setting + ' is ' + this.esData.settings[this.utils.camelize(setting)] + ',';
            showOutput += '' + setting + ': (' + this.esData.settings[this.utils.camelize(setting)] + ')<br/>';
        });
        showOutput += '</font>';
        speechOutput += "that's all for the status.";
        this.attributes.speechOutput = speechOutput;
        this.attributes.repromptSpeech = this.utils.getSpeechItem(this.respMap.Help, 'Reprompts', this.allowPersonality).toString();
        this.response.speak(this.utils.convSpeechOutput(this.attributes.speechOutput)).listen(this.utils.convSpeechOutput(this.attributes.repromptSpeech));
        if (this.echoHasDisplay === true) {
            const template = this.utils.generateShowCard({
                skillName: this.skillName,
                priText: showOutput,
                type: 'body3'
            });
            this.response.renderTemplate(template);
        }
        return this.emit(':responseReady');
    }
}
module.exports = StatusInfo;