'use strict';
/*
 *  EchoSistantV5 - Lambda Code
 *  Designed and Written By: Corey Lista and Anthony Santilli
 *
 *
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 */
const appVersion = '5.0.0110';
const appVerDate = '01/10/2018';
const Alexa = require('./alexa-sdk');
const aws = require('aws-sdk');
const TextUtils = Alexa.utils.TextUtils;
const ImageUtils = Alexa.utils.ImageUtils;
const AlexaShowTemplates = Alexa.templateBuilders;
let Skill_Name = 'EchoSistant Evolution';
var alexa;

// This defines the echosistant objects in /echosistant folder
const EchoSistant = require('./echosistant');

exports.handler = function(event, context, callback) {
    if (event.path === '/esData') {
        const doc = new aws.DynamoDB.DocumentClient({
            apiVersion: '2012-08-10',
            convertEmptyValues: true
        });
        doc.put(JSON.parse(event.body), function(err, data) {
            if (err) {
                console.error('ESLogging| Error during DynamoDB put:' + err);
            }
            if (Object.keys(data).length) {
                console.log('ESLogging| handleDbUpdates: ', data);
            }
            callback(err, {
                statusCode: 200,
                body: JSON.stringify({
                    lambdaInfo: { version: appVersion, versionDt: appVerDate }
                })
            });
        });
    } else {
        // sendVoiceMessage('Checking', event);
        alexa = new Alexa.handler(event, context, callback);
        alexa.dynamoDBTableName = 'EchoSistantV5';
        alexa.registerHandlers(alexaHandlers);
        alexa.execute();
    }
};

const alexaHandlers = {
    LaunchRequest: function() {
        console.log('LaunchRequest');
        const allowPersonality = this.esData.settings.allowPersonality !== false;
        const respMap = new EchoSistant(this).respMap();
        this.attributes.speechOutput = getSpeechItem(respMap.Welcome, 'Default', allowPersonality).toString();
        this.attributes.repromptSpeech = getSpeechItem(respMap.Welcome, 'Reprompts', allowPersonality).toString();
        this.response.speak(convSpeechOutput(this.esData.settings.quietMode, this.attributes.speechOutput)).listen(convSpeechOutput(this.esData.settings.quietMode, this.attributes.repromptSpeech));

        if (this.event.context.System.device.supportedInterfaces.Display) {
            const template = generateShowCard({
                skillName: Skill_Name,
                bgImage: this.esData.locData.showBgWallpaper,
                priText: this.attributes.speechOutput,
                type: 'body6'
            });
            this.response.renderTemplate(template);
        }
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('LaunchRequest', this);
        }
        this.emit(':responseReady');
    },
    IntentRequest: function() {
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('IntentRequest-' + this.event.request.intent.name, this);
        }
        console.log('IntentRequest: ' + this.event.request.intent.name);
        this.emit(this.event.request.intent.name);
    },
    'AMAZON.HelpIntent': function() {
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('HelpIntent', this);
        }
        console.log('HelpIntent: ' + this.event.request.intent.name);
        if (this.attributes.helpStage === undefined) {
            this.attributes.helpStage = 'needHelpType';
        }
        this.attributes.helpInUse === true;
        new EchoSistant(this).helpClass().handleHelp();
    },
    'AMAZON.RepeatIntent': function() {
        console.log('RepeatIntent');
        this.response.speak(convSpeechOutput(this.esData.settings.quietMode, this.attributes.speechOutput)).listen(convSpeechOutput(this.esData.settings.quietMode, this.attributes.repromptSpeech));
        this.emit(':responseReady');
    },
    'AMAZON.NoIntent': function() {
        console.log('NoIntent');
        this.attributes.speechOutput = undefined;
        this.emit('SessionEndedRequest');
    },
    'AMAZON.StopIntent': function() {
        console.log('StopIntent');
        const respMap = new EchoSistant(this).respMap();
        this.attributes.speechOutput = getSpeechItem(respMap.Stop, 'Default', this.esData.settings.allowPersonality !== false).toString();
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function() {
        console.log('CancelIntent');
        const respMap = new EchoSistant(this).respMap();
        this.attributes.speechOutput = getSpeechItem(respMap.Stop, 'Default', this.esData.settings.allowPersonality !== false).toString();
        this.emit('SessionEndedRequest');
    },
    SessionEndedRequest: function() {
        console.log('SessionEndedRequest');
        const respMap = new EchoSistant(this).respMap();
        // This cleans up the device attributes right before the session ends.
        const items = ["usingHere", "commandBeforeHere", "setModeStage", "setTypeOpts", "setModeSetting", "helpStage", "helpType", "helpModeType", "helpModeStage", "hereDevId", "hereInUse", "helpInUse", "lastHandler"];
        for (const i of items) {
            this.attributes[i.toString()] = undefined;
        }
        if (this.event.session.user.userId !== undefined) {
            this.attributes.userId = this.event.session.user.userId;
        }
        if (this.attributes.speechOutput === undefined) {
            this.attributes.speechOutput = getSpeechItem(respMap.Stop, 'Default', this.esData.settings.allowPersonality !== false).toString();
        }
        this.response.speak(convSpeechOutput(this.esData.settings.quietMode, this.attributes.speechOutput));
        if (this.event.context.System.device.supportedInterfaces.Display) {
            this.response.renderTemplate(
                generateShowCard({
                    skillName: Skill_Name,
                    bgImage: this.esData.locData.showBgWallpaper,
                    priText: this.attributes.speechOutput,
                    type: 'body6'
                })
            );
        }
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('SessionEndedRequest', this);
        }
        this.emit(':responseReady');
    },

    Here: function() {
        let intType;
        var ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        console.log(ttstext ? 'Here Intent | ttstext: ' + ttstext : 'Here Intent');
        this.attributes.hereInUse === true;
        // This will store the here skill id in the DB so we can determine if the settings call came from Here
        let roomObj = this.hereData || {};
        if (roomObj.hereId === undefined) {
            roomObj.hereId = this.event.session.application.applicationId;
        }
        this.hereData = roomObj;
        let hereDevSetOk = this.hereData.echoDevices !== undefined && this.hereData.echoDevices[this.handler.theId] !== undefined && this.hereData.echoDevices[this.handler.theId]['room'] !== undefined;
        if (hereDevSetOk === false && this.attributes.setModeStage === undefined) {
            if (this.attributes.usingHere === undefined) {
                this.attributes.usingHere = 'FirstCall';
            }
            intType = 'Here';
            new EchoSistant(this).here().handleHere();
        } else if (this.attributes.setModeStage !== undefined) {
            intType = 'Here-Settings';
            this.attributes.hereDevId = this.handler.theId;
            new EchoSistant(this).here().handleHere();
        } else if (this.attributes.helpStage !== undefined) {
            intType = 'Here-Settings';
            this.attributes.hereDevId = this.handler.theId;
            new EchoSistant(this).helpClass().handleHelp();
        } else {
            intType = 'Here-Parser';
            new EchoSistant(this).parser().findDevices();
        }
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('Here-' + intType, this);
        }
    },

    AppStatus: function() {
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('AppStatus-Intent', this);
        }
        console.log(ttstext ? 'AppStatus Intent | ttstext: ' + ttstext : 'AppStatus Intent');
        var ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        new EchoSistant(this).statusInfo().appStatus();
    },

    UpdateSettings: function() {
        var ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        console.log(ttstext ? 'UpdateSettings | ttstext: ' + ttstext : 'UpdateSettings');

        if (this.attributes.helpInUse) {
            this.attributes.helpStage = undefined;
            this.attributes.helpInUse = undefined;
        }
        let hereDevSetOk = this.hereData.echoDevices !== undefined && this.hereData.echoDevices[this.handler.theId] !== undefined && this.hereData.echoDevices[this.handler.theId]['room'] !== undefined;
        if (this.attributes.setModeStage !== undefined || !['needSetName', 'needSetValue', 'needDevPrefs'].includes(this.attributes.setModeStage)) {
            this.attributes.setModeStage = 'needSetType';
        }
        if (this.hereData.hereId !== undefined && this.event.session.application.applicationId !== undefined && hereDevSetOk === true) {
            if (this.hereData.hereId.toString() === this.event.session.application.applicationId.toString()) {
                this.attributes.setTypeOpts = ['app preferences', 'echo devices'];
            }
        }
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('UpdateSettings-Intent', this);
        }
        new EchoSistant(this).settings().handleSettings(this.attributes.setTypeOpts);
    },

    Unhandled: function() {
        let intType;
        let ttstext = this.event.request.intent.slots !== undefined && this.event.request.intent.slots.ttstext !== undefined ? this.event.request.intent.slots.ttstext.value : undefined;
        console.log(ttstext ? 'Unhandled Intent | ttstext: ' + ttstext : 'Unhandled Intent');
        if (this.attributes.usingHere !== undefined) {
            intType = 'Here';
            new EchoSistant(this).here().handleHere();
        } else if (this.attributes.setModeStage !== undefined) {
            intType = 'Settings';
            console.log('Unhandled(setModeStage: ' + this.attributes.setModeStage + ')');
            new EchoSistant(this).settings().handleSettings();
        } else if (this.attributes.helpStage !== undefined) {
            intType = 'Help';
            console.log('Unhandled(helpStage: ' + this.attributes.helpStage + ')');
            new EchoSistant(this).helpClass().handleHelp();
        } else {
            intType = 'Parser';
            new EchoSistant(this).parser().findDevices();
        }
        if (this.esData.settings.sendDebugData === true) {
            new EchoSistant(this).debug().sendRequestLogs('Unhandled-' + intType, this);
        }
    }
};

function convSpeechOutput(quietMode, str) {
    // console.log("convSpeechOutput | Before: " + str);
    if (quietMode === true) {
        str = "<amazon:effect name='whispered'>" + str + '</amazon:effect>';
    }
    // console.log("convSpeechOutput | After: " + str);
    return str;
}

function sendVoiceMessage(message, event) {
    const requestId = event.request.requestId;
    const token = event.context.System.apiAccessToken;
    const endpoint = event.context.System.apiEndpoint;
    const ds = new Alexa.services.DirectiveService();
    const directive = new Alexa.directives.VoicePlayerSpeakDirective(requestId, message);
    ds.enqueue(directive, endpoint, token).catch(err => {
        console.log('sendVoiceMessage', err);
    });
}

function generateShowCard(paramsMap) {
    let output;
    let imgPathUrl = 'https://echosistant.com/es5_content/images/';
    var builder;
    let title = paramsMap.skillName;
    let priText = TextUtils.makeRichText(paramsMap.priText);
    let secText = paramsMap.secText !== undefined ? TextUtils.makeRichText(paramsMap.secText) : undefined;
    let tertText = paramsMap.terText !== undefined ? TextUtils.makeRichText(paramsMap.terText) : undefined;
    let bgImg = paramsMap.bgImage === undefined ? ImageUtils.makeImage(imgPathUrl + 'default.png') : ImageUtils.makeImage(imgPathUrl + 'show_bg/' + paramsMap.bgImage + '.png');
    let sideImgSize = paramsMap.sideImageSize === undefined ? undefined : paramsMap.sideImageSize;
    let sideImg = paramsMap.sideImage === undefined ? ImageUtils.makeImage(imgPathUrl + 'echosistant_v5_512px.png', sideImgSize) : ImageUtils.makeImage(imgPathUrl + paramsMap.sideImage, sideImgSize);
    let token = paramsMap.token === undefined ? undefined : paramsMap.token;
    let listItems = paramsMap.listItems === undefined ? undefined : paramsMap.listItems;
    let templateStyle = paramsMap.type === undefined ? 'default' : paramsMap.type;
    let showBackBtn = paramsMap.showBackBtn !== true ? 'HIDDEN' : 'VISIBLE';
    switch (templateStyle) {
        case 'body1':
            builder = new AlexaShowTemplates.BodyTemplate1Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setTextContent(priText, secText, tertText).setToken(token).build();
            break;
        case 'body2':
            builder = new AlexaShowTemplates.BodyTemplate2Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
            break;
        case 'body3':
            builder = new AlexaShowTemplates.BodyTemplate3Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
            break;
        case 'body7':
            builder = new AlexaShowTemplates.BodyTemplate7Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setImage(sideImg).setTextContent(priText, secText, tertText).setToken(token).build();
            break;

        case 'list1':
            builder = new AlexaShowTemplates.ListTemplate1Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setListItems(listItems).setToken(token).build();
            break;
        case 'list2':
            builder = new AlexaShowTemplates.ListTemplate2Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setTitle(title).setBackgroundImage(bgImg).setListItems(listItems).setToken(token).build();
            break;
        default:
            builder = new AlexaShowTemplates.BodyTemplate6Builder();
            output = builder.setBackButtonBehavior(showBackBtn).setBackgroundImage(bgImg).setTextContent(priText, secText, tertText).setToken(token).build();
            break;
    }
    return output;
}

function getRandomItem(items) {
    const res = items[Math.floor(Math.random() * items.length)];
    console.log('res: ' + res);
    return res;
}

// This alternative to getRandomItem allows us to filter out the attitude responses
function getSpeechItem(itemObj, keyName, attitude) {
    let items = [];
    if (attitude !== false) {
        items = [...new Set([...itemObj[keyName], ...itemObj[keyName + '_Attitude']])];
    } else {
        items = itemObj[keyName];
    }
    return items[Math.floor(Math.random() * items.length)];
}