'use strict';
const aws = require('aws-sdk');

class Database {
    constructor(esClass) {
        this.appVersion = esClass.appVersion;
        this.appVerDate = esClass.appVerDate;
        this.attributes = esClass.alexaHandler.attributes;
        this.response = esClass.alexaHandler.response;
        this.alexaHandler = esClass.alexaHandler;
        this.event = esClass.alexaHandler.event;
        this.esData = esClass.esData;
        this.respMap = esClass.respStrings;
        this.utils = esClass.utils;
        this.devId = esClass.alexaHandler.handler.theId;
        this.devName = esClass.devName;
        this.stAppID = process.env.stPath.split('/')[4];
    }
    handleDbUpdates(body, callback) {
        const doc = new aws.DynamoDB.DocumentClient({
            apiVersion: '2012-08-10',
            convertEmptyValues: true
        });
        doc.put(JSON.parse(body), function(err, data) {
            if (err) {
                console.error('ESLogging | Error during DynamoDB put:' + err);
            }
            if (Object.keys(data).length) {
                console.log('ESLogging | handleDbUpdates: ', data);
            }
            callback(err, {
                lambdaInfo: {
                    version: this.appVersion,
                    versionDt: this.appVerDate
                }
            });
        });
    }

    sendAnalyticsToFb() {
        const self = this;
        if (self.esData.locData.optInAnalytics === true) {
            const payload = JSON.stringify({
                lambVer: self.appVersion,
                lambDt: self.appVerDate,
                collectedData: this.esData.analyticsData.collectedData,
                tz: new Date().toString()
            });
            // console.log('sendRequestLogs: ' + payload);
            const postHeaders = {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(payload, 'utf8')
            };
            const options = {
                host: 'echosistant-analytics.firebaseio.com',
                path: '/analytics/analytics.json',
                port: '443',
                method: 'POST',
                headers: postHeaders
            };
            self.utils
                .httpRequest(options, payload)
                .then(function(resp) {
                    console.log('ESLogging | sendAnalyticsToFb: ', JSON.stringify(resp));
                })
                .catch(function(err) {
                    console.error('ESLogging | sendAnalyticsToFb Error: ', err);
                });
        }
    }
}
module.exports = Database;